<?php

$config = array(
	'protocol'		=> 'smtp',
	'mailtype'		=> 'html',
	'crlf'			=> '\r\n',
	'newline'		=> '\r\n'
);