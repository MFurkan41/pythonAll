

<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $this->module->arguments->title ?>
                </div>

                <div class="contact-details box-body">
                    <div class="row">

                        <div class="column col-md-6">
                            <?php echo $this->module->arguments->detail ?>
                        </div>
                        <div class="column col-md-6">



                            <?php echo $this->site->alert() ?>
                            <form method="post" action="<?php echo current_url() ?>#form">
                                <div class="form-group">
                                    <label for="fullname">Adınız Soyadınız</label>
                                    <input type="text" name="fullname" id="fullname" class="form-control" required="required" value="<?php echo set_value('fullname') ?>" />
                                </div>

                                <div class="row">
                                    <div class="column col-md-6">
                                        <div class="form-group">
                                            <label for="email">E-Mail</label>
                                            <input type="email" name="email" id="email" class="form-control" required="required" value="<?php echo set_value('email') ?>" />
                                        </div>
                                    </div>
                                    <div class="column col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Telefon</label>
                                            <input type="text" name="phone" id="phone" class="form-control mask-phone" required="required" value="<?php echo set_value('phone') ?>" />
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="comment">Mesajınız</label>
                                    <textarea name="comment" id="comment" class="form-control" required="required" rows="5"><?php echo set_value('comment') ?></textarea>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Gönder</button>
                                </div>
                            </form>
                        </div>
                    </div>



                    <h3>Harita</h3>
                    <div class="googlemap">
                        <div id="map"></div>
                    </div>


                    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=APIKEYBURAYAYAZILACAKTIR&sensor=false"></script>
                    <script type="text/javascript">
                        function initialize() {
                            var myLatlng = new google.maps.LatLng(<?php echo $this->module->arguments->googleMap ?>);
                            var mapOptions = {
                                zoom: 13,
                                center: myLatlng,
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            };

                            var map = new google.maps.Map(document.getElementById('map'), mapOptions);

                            var contentString = '<?php echo htmlspecialchars($this->module->arguments->googleMapText) ?>';

                            var infowindow = new google.maps.InfoWindow({
                                content: contentString,
                                maxWidth: 200
                            });

                            var marker = new google.maps.Marker({
                                position: myLatlng,
                                map: map,
                                title: '<?php htmlspecialchars($this->module->arguments->title) ?>'
                            });
                            google.maps.event.addListener(marker, 'click', function() {
                                infowindow.open(map,marker);
                            });
                        }

                        google.maps.event.addDomListener(window, 'load', initialize);

                    </script>


                </div>

            </div>

        </div>
    </div>
</section>


