
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>

        <div class="column col-sm-6 col-md-9">


            <div class="page-title">
                <?php echo $pageTitle ?>
            </div>

            <div class="estate-details">
                <div class="row">

                    <?php foreach ($estates as $estate): ?>
                        <div class="column col-md-4">
                            <div class="estate">
                                <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                                    <img src="<?php echo uploadPath($estate->image, 'estate') ?>" />
                                </a>
                                <div class="detail">
                                    <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                                        <span class="price"><?php echo money($estate->price) ?> TL</span>
                                        <strong><?php echo $estate->districtTitle ?></strong>
                                        <?php echo $estate->estateStatus ?> <?php echo $estate->typeTitle ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>


                <div class="text-center">
                    <?php if (! empty($pagination)): ?>
                        <?php echo $pagination ?>
                    <?php endif; ?>
                </div>
            </div>


        </div>
    </div>
</section>
