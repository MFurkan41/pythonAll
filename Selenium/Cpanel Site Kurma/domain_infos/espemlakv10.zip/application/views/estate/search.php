
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>

        <div class="column col-sm-6 col-md-9">


            <div class="page-title">
                Arama Sonuçları
            </div>

            <div class="panel panel-default">
                <div class="panel-body" style="padding: 10px;">
                    <div class="pull-right form-inline">
                        <label>Sırala: </label>
                        <select id="sort-price" name="sortPrice" class="form-control input-sm" data-url="<?php echo clink('@search', null, true) ?>">
                            <option value="desc" <?php echo $this->input->get('sortPrice') == 'desc' ? 'selected':'' ?>>Pahalıdan Ucuza</option>
                            <option value="asc" <?php echo $this->input->get('sortPrice') == 'asc' ? 'selected':'' ?>>Ucuzdan Pahalıya</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="estate-details">
                <?php if ($estates): ?>
                    <div class="row">

                        <?php foreach ($estates as $estate): ?>
                            <div class="column col-md-4">
                                <div class="estate">
                                    <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                                        <img src="<?php echo uploadPath($estate->image, 'estate') ?>" />
                                    </a>
                                    <div class="detail">
                                        <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                                            <span class="price"><?php echo money($estate->price) ?> TL</span>
                                            <strong><?php echo $estate->districtTitle ?></strong>
                                            <?php echo $estate->estateStatus ?> <?php echo $estate->typeTitle ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>


                    <div class="text-center">
                        <?php if (! empty($pagination)): ?>
                            <?php echo $pagination ?>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p>Kayıt bulunamadı.</p>
                <?php endif; ?>
            </div>


        </div>
    </div>
</section>
