
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">


            <?php $this->view('layout/rightside') ?>


        </div>

        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $estate->title. ' ' .$estate->title2 ?>
                </div>

                <div class="estate-details box-body">
                    <div class="row">
                        <div class="column col-md-6">
                            <div class="images">
                                <?php if ($estate->images): ?>
                                    <div id="estate-image" class="image">
                                        <ul>
                                            <?php foreach ($estate->images as $item): ?>
                                                <li><a class="fancybox" rel="gallery" href="<?php echo uploadPath($item->image, 'estate/large') ?>"><img src="<?php echo uploadPath($item->image, 'estate/normal') ?>" alt="" /></a></li>
                                            <?php endforeach; ?>
                                        </ul>

                                    </div>
                                    <div id="estate-thumbs" class="thumbs clearfix">
                                        <?php foreach ($estate->images as $index => $item): ?>
                                            <a data-slide-index="<?php echo $index ?>" href=""><img src="<?php echo uploadPath($item->image, 'estate/thumb') ?>" alt="" /></a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="image"><img src="<?php echo uploadPath($estate->image, 'estate') ?>" alt="" /></div>
                                <?php endif; ?>
                            </div>
					
							<div class="column group hidden-xs">
                                <h3>Açıklama</h3>
                                <?php echo $estate->description ?>

                                <?php if (! empty($estate->video)): ?>
                                    <div class="video">
                                        <div class="row">
                                            <div class="column col-xs-3 col-sm-4">
                                                <a class="fancybox fancybox.iframe" style="color: #333;" href="https://www.youtube.com/embed/<?php echo $estate->video ?>?autoplay=0&rel=0&showinfo=0">
                                                    <img class="img-responsive" src="//i.ytimg.com/vi/<?php echo $estate->video ?>/default.jpg" />
                                                </a>
                                            </div>
                                            <div class="column col-xs-9 col-sm-8">
                                                <a class="fancybox fancybox.iframe" style="color: #333;" href="https://www.youtube.com/embed/<?php echo $estate->video ?>?autoplay=0&rel=0&showinfo=0">
                                                    <p style="margin-bottom: 5px;"><strong>Emlak Videosunu İzle</strong></p>
                                                    Videosunu izleyerek emlağı çok daha kolay inceleyebilirsiniz.
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>

                        <div class="column col-md-6">

                            <div class="details">
                                <div class="item clearfix">
                                    <span><strong>Fiyat:</strong></span>
                                    <span class="large"><?php echo money($estate->price) ?> TL</span>
                                </div>
                                <div class="item clearfix">
                                    <span><strong>Emlak No:</strong></span>
                                    <span><?php echo $estate->no ?></span>
                                </div>

                                <div class="item clearfix">
                                    <span><strong>İl:</strong></span>
                                    <span><?php echo $estate->cityTitle ?></span>
                                </div>

                                <div class="item clearfix">
                                    <span><strong>İlçe:</strong></span>
                                    <span><?php echo $estate->townTitle ?></span>
                                </div>

                                <div class="item clearfix">
                                    <span><strong>Semt:</strong></span>
                                    <span><?php echo $estate->districtTitle ?></span>
                                </div>

                                <div class="item clearfix">
                                    <span><strong>Emlak Türü:</strong></span>
                                    <span><?php echo $estate->kindTitle ?></span>
                                </div>

                                <div class="item clearfix">
                                    <span><strong>Emlak Tipi:</strong></span>
                                    <span><?php echo $estate->estateStatus .' '. $estate->typeTitle ?></span>
                                </div>

                                <?php if (! empty($estate->roomTitle)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Oda Sayısı:</strong></span>
                                        <span><?php echo $estate->roomTitle ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->bath)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Banyo Sayısı:</strong></span>
                                        <span><?php echo $estate->bath ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->squaremeter)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Metrekare:</strong></span>
                                        <span><?php echo $estate->squaremeter ?> m2</span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->floorTitle)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Bulunduğu Kat:</strong></span>
                                        <span><?php echo $estate->floorTitle ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->storeyCount)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Binadaki Kat Sayısı:</strong></span>
                                        <span><?php echo $estate->storeyCount ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->buildingAgeTitle)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Binanın Yaşı:</strong></span>
                                        <span><?php echo $estate->buildingAgeTitle ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->heatingTitle)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Isıtma Şekli:</strong></span>
                                        <span><?php echo $estate->heatingTitle ?></span>
                                    </div>
                                <?php endif; ?>

                                <?php if (! empty($estate->usageStatusTitle)): ?>
                                    <div class="item clearfix">
                                        <span><strong>Kullanım Durumu:</strong></span>
                                        <span><?php echo $estate->usageStatusTitle ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
							
							<div class="column group visible-xs">
                                <h3>Açıklama</h3>
                                <?php echo $estate->description ?>

                                <?php if (! empty($estate->video)): ?>
                                    <div class="video">
                                        <div class="row">
                                            <div class="column col-xs-3 col-sm-4">
                                                <a class="fancybox fancybox.iframe" style="color: #333;" href="https://www.youtube.com/embed/<?php echo $estate->video ?>?autoplay=0&rel=0&showinfo=0">
                                                    <img class="img-responsive" src="//i.ytimg.com/vi/<?php echo $estate->video ?>/default.jpg" />
                                                </a>
                                            </div>
                                            <div class="column col-xs-9 col-sm-8">
                                                <a class="fancybox fancybox.iframe" style="color: #333;" href="https://www.youtube.com/embed/<?php echo $estate->video ?>?autoplay=0&rel=0&showinfo=0">
                                                    <p style="margin-bottom: 5px;"><strong>Emlak Videosunu İzle</strong></p>
                                                    Videosunu izleyerek emlağı çok daha kolay inceleyebilirsiniz.
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
							
							<div style="margin-top: 15px;">
								<?php echo $this->module->arguments->contactInfoText ?>

								<div class="row">
									<div class="column col-sm-1"><span class="glyphicon glyphicon-map-marker text-primary" style="font-size: 26px;"></span></div>
									<div class="column col-sm-11">
										<?php echo $this->module->arguments->contactAddress ?>
									</div>
								</div>

								<div class="row">
									<div class="column col-sm-1"><span class="glyphicon glyphicon-phone-alt text-primary" style="font-size: 22px;"></span></div>
									<div class="column col-sm-11">
										<?php echo $this->module->arguments->contactPhone ?>
									</div>
								</div>
								
							</div>
							
							
							

                        </div>
                    </div>
							<div class="share-box share-box-view">
								<p><strong>Sosyal Medyada Paylaşın</strong></p>
								<a class="facebook" href="http://facebook.com/sharer.php?u=<?php echo current_url() ?>" title="Facebook'ta Paylaş">Facebook'ta Paylaş</a>
								<a class="twitter" href="https://twitter.com/share?url=<?php echo current_url() ?>&text=<?php echo htmlspecialchars($estate->title) ?>" title="Twitter'da Paylaş">Twitter'da Paylaş</a>
								<a class="google" href="https://plus.google.com/share?url=<?php echo current_url() ?>" title="Google+'ta Paylaş">Google+'ta Paylaş</a>
							</div>



                    <div class="group">
                        <h3>Emlak Özellikleri</h3>
                        <div class="properties row">
                            <?php foreach ($estate->properties as $property): ?>
                                <div class="column col-md-4"><?php echo $property->title ?></div>
                            <?php endforeach; ?>
                        </div>
                    </div>
					
					<div class="row">
                            


                            <?php if (! empty($estate->mapCoordinate)): ?>
                                <div class="column group col-md-12">
                                    <h3>Konumu</h3>
                                    <div class="googlemap"><div id="map"></div></div>

                                    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
                                    <script type="text/javascript">
                                        function initialize() {
                                            var myLatlng = new google.maps.LatLng(<?php echo $estate->mapCoordinate ?>);
                                            var mapOptions = {
                                                zoom: 14,
                                                center: myLatlng,
                                                mapTypeId: google.maps.MapTypeId.ROADMAP
                                            };

                                            var map = new google.maps.Map(document.getElementById('map'), mapOptions);

                                            new google.maps.Marker({
                                                position: myLatlng,
                                                map: map
                                            });
                                        }

                                        google.maps.event.addDomListener(window, 'load', initialize);
                                    </script>

                                    <div class="text-right">
                                        <a class="btn btn-primary btn-xs" href="http://maps.google.com/?q=<?php echo $estate->mapCoordinate ?>" target="_blank">
                                            <span class="glyphicon glyphicon-fullscreen"></span> Büyük Harida Göster
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>


                    <div class="group">
                        <h3 id="contact">İletişime Geçin</h3>
                        <div class="contact row">
                            <div class="column col-md-6">
                                <?php echo $this->module->arguments->contactFormText ?>
                                <?php echo $this->site->alert() ?>
                                <form method="post" action="<?php echo current_url() ?>#contact">
                                    <div class="row">
                                        <div class="column col-md-6 form-group">
                                            <input name="fullname" class="form-control" placeholder="Adınız Soyadınız">
                                        </div>

                                        <div class="column col-md-6 form-group">
                                            <input name="phone" class="form-control mask-phone" placeholder="Telefon Numaranız">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <textarea name="message" class="form-control" placeholder="Mesajınız"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success">Gönder</button>
                                    </div>
                                </form>
                            </div>


                            <div class="column col-md-6 hide">
                                <?php echo $this->module->arguments->contactInfoText ?>

                                <div class="row">
                                    <div class="column col-sm-1"><span class="glyphicon glyphicon-map-marker text-primary" style="font-size: 26px;"></span></div>
                                    <div class="column col-sm-11">
                                        <?php echo $this->module->arguments->contactAddress ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="column col-sm-1"><span class="glyphicon glyphicon-phone-alt text-primary" style="font-size: 22px;"></span></div>
                                    <div class="column col-sm-11">
                                        <?php echo $this->module->arguments->contactPhone ?>
                                    </div>
                                </div>




                            </div>
                        </div>
                    </div>

                </div>

            </div>




        </div>
    </div>
</section>
