
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">
            <div class="box">
                <div class="box-header">Kategoriler</div>
                <div class="box-body">
                    <ul class="navigation">
                        <li><a href="<?php echo clink('@blog') ?>" title="Blog">Blog Anasayfa</a></li>
                        <?php foreach ($categories as $item): ?>
                            <li class="<?php echo isset($category) && $category->id === $item->id ? 'active':'' ?>">
                                <a href="<?php echo clink(array('@blogcategory', $item->slug, $item->id)) ?>" title="<?php echo htmlspecialchars($item->title) ?>"><?php echo $item->title ?>
                                    <span class="pull-right glyphicon glyphicon-chevron-right"></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $this->module->arguments->title ?>
                </div>

                <div class="box-body posts">
                    <div class="row">

                        <?php foreach ($posts as $post): ?>
                            <div class="column col-md-4">
                                <div class="post">
                                    <a href="<?php echo clink(array('@blogpost', $post->slug, $post->id)) ?>" title="<?php echo htmlspecialchars($post->title) ?>">
                                        <img class="img-responsive" src="<?php echo uploadPath($post->image, 'blog') ?>" alt="<?php echo htmlspecialchars($post->title) ?>" />
                                        <span class="title"><?php echo $post->title ?></span>
                                        <span class="summary"><?php echo $post->summary ?></span>
                                    </a>
                                    <span class="category">
                                        <a href="<?php echo clink(array('@blogcategory', $post->categorySlug, $post->categoryId)) ?>" title="<?php echo htmlspecialchars($post->categoryTitle) ?>">
                                            <?php echo $post->categoryTitle ?>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>

                    <div class="text-center">
                        <?php if (! empty($pagination)): ?>
                            <?php echo $pagination ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

