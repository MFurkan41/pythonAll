
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">
            <div class="box">
                <div class="box-header">Kategoriler</div>
                <div class="box-body">
                    <ul class="navigation">
                        <li><a href="<?php echo clink('@blog') ?>" title="Blog">Blog Anasayfa</a></li>
                        <?php foreach ($categories as $item): ?>
                            <li class="<?php echo isset($category) && $category->id === $item->id ? 'active':'' ?>">
                                <a href="<?php echo clink(array('@blogcategory', $item->slug, $item->id)) ?>" title="<?php echo htmlspecialchars($item->title) ?>"><?php echo $item->title ?>
                                    <span class="pull-right glyphicon glyphicon-chevron-right"></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $this->module->arguments->title ?> / <?php echo $category->title ?> / <?php echo $post->title ?>
                </div>

                <div class="box-body">
                    <?php echo $post->detail ?>

                    <p>
                        <br />
                        <a class="btn btn-primary btn-sm" href="javascript:history.back();"><span class="glyphicon glyphicon-circle-arrow-left"></span> Geri Dön</a>
                        <a class="btn btn-primary btn-sm" href="<?php echo clink('@blog') ?>">Blog Anasayfa</a>
                    </p>

                    <div class="share-box">
                        <p><strong>Sosyal Medyada Paylaşın</strong></p>
                        <a class="facebook" href="http://facebook.com/sharer.php?u=<?php echo current_url() ?>" title="Facebook'ta Paylaş">Facebook'ta Paylaş</a>
                        <a class="twitter" href="https://twitter.com/share?url=<?php echo current_url() ?>&text=<?php echo htmlspecialchars($post->title) ?>" title="Twitter'da Paylaş">Twitter'da Paylaş</a>
                        <a class="google" href="https://plus.google.com/share?url=<?php echo current_url() ?>" title="Google+'ta Paylaş">Google+'ta Paylaş</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

