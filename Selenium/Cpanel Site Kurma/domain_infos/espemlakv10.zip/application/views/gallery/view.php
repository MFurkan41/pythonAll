
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="page-title">
                <?php echo $gallery->title ?>
            </div>

            <div class="galleries">
                <div class="row">

                    <?php foreach ($gallery->images as $image): ?>
                        <div class="column col-md-3">
                            <div class="gallery">
                                <a class="fancybox" rel="gallery" href="<?php echo uploadPath($image->image, 'gallery/normal') ?>">
                                    <img class="img-responsive" src="<?php echo uploadPath($image->image, 'gallery/thumb') ?>" />
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>

                </div>

                <p>
                    <br />
                    <a class="btn btn-primary btn-sm" href="javascript:history.back();"><span class="glyphicon glyphicon-circle-arrow-left"></span> Geri Dön</a>
                    <a class="btn btn-primary btn-sm" href="<?php echo clink('@gallery') ?>">Tüm Galeriler</a>
                </p>
            </div>


        </div>
    </div>
</section>
