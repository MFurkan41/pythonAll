<!--script type="text/javascript">
/* ### POPUP ### */
    $(document).ready(function() {
        $("#popup").fancybox().trigger('click');
    });
/*  */
</script>
<div id="popup">
<img src="public/img/bayram.jpg" />
</div-->

<section id="latest" class="container">
    <h2><span class="glyphicon glyphicon-play"></span> <strong class="yellow">KİRALIK</strong> İLANLAR</h2>
    <div class="row">
        <?php foreach ($lastRentEstates as $estate): ?>
            <div class="column col-xs-12 col-sm-6 col-md-3">
                <div class="estate yellow">
                    <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                        <img src="<?php echo uploadPath($estate->image, 'estate') ?>" />
                    </a>
                    <div class="detail">
                        <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                            <span class="price"><?php echo money($estate->price) ?> TL</span>
							<h3><?= ! empty($estate->title) ? $estate->title : '' ?></h3>
                            <p class="lip"><?php echo $estate->districtTitle ?> - <?php echo $estate->estateStatus ?> <?php echo $estate->typeTitle ?></p>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>



    <h2><span class="glyphicon glyphicon-play"></span> <strong>SATILIK</strong> İLANLAR</h2>
    <div class="row">

        <?php foreach ($lastSaleEstates as $estate): ?>
            <div class="column col-xs-12 col-sm-6 col-md-3">
                <div class="estate">
                    <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                        <img src="<?php echo uploadPath($estate->image, 'estate') ?>" />
                    </a>
                    <div class="detail">
                        <a href="<?php echo clink(array('@estate', $estate->id)) ?>">
                            <span class="price"><?php echo money($estate->price) ?> TL</span>
							<h3><?= ! empty($estate->title) ? $estate->title : '' ?></h3>
                            <p class="lip <?= ! empty($estate->title) ? 'font12' : '' ?>">
								<strong><?php echo $estate->districtTitle ?> - <?php echo $estate->estateStatus ?> <?php echo $estate->typeTitle ?></strong>
							</p>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>


    </div>


</section>



<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>

        <div class="column col-sm-6 col-md-9">

            <?php if ($showcases): ?>
                <div class="showcases clearfix visible-lg">
                    <?php foreach ($showcases as $showcaseIndex => $showcase): ?>
                        <div class="showcase <?php echo $showcaseStyle[$showcaseIndex] ?>">
                            <ul>
                                <?php foreach ($showcase as $slide): ?>
                                <li>
                                    <a href="<?php echo clink(array('@estate', $slide->estateId)) ?>">
                                        <img src="public/img/transparent.png" alt="" style="background-image: url(<?php echo uploadPath($slide->image, 'estate') ?>)"/>
                                        <div class="content">
                                            <div class="price"><?php echo money($slide->price) ?> TL</div>
                                            <div class="district"><?php echo $slide->districtTitle ?></div>
                                            <div class="type"><?php echo $slide->typeTitle ?></div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="posts box">
                <div class="box-header"><a href="<?php echo clink('@blog') ?>">Blog</a></div>
                <div class="box-body">
                    <div class="row">
                        <?php foreach ($blogs as $blog): ?>
                            <div class="column col-md-3">
                                <div class="post normal" style="font-size: 12px;">
                                    <a href="<?php echo clink(array('@blogpost', $blog->slug, $blog->id)) ?>" title="<?php echo htmlspecialchars($blog->title) ?>">
                                        <img src="<?php echo uploadPath($blog->image, 'blog') ?>" alt="<?php echo htmlspecialchars($blog->title) ?>" />
                                        <span class="title"><?php echo $blog->title ?></span>
                                        <span class="summary"><?php echo $blog->summary ?></span>
                                    </a>
                                    <span class="category">
                                        <a href="<?php echo clink(array('@blogcategory', $blog->categorySlug, $blog->categoryId)) ?>" title="<?php echo htmlspecialchars($blog->categoryTitle) ?>">
                                            <?php echo $blog->categoryTitle ?>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>


            <div class="partners row">
                <?php foreach ($partners as $partner): ?>
                    <div class="column col-md-4">
                        <div class="partner">
							<a href="<?php echo $partner->link ?>" target="_blank" title="<?php echo htmlspecialchars($partner->title) ?>">
								<img src="<?php echo uploadPath($partner->image, 'partner') ?>" alt="<?php echo htmlspecialchars($partner->title) ?>" title="<?php echo htmlspecialchars($partner->title) ?>" />
							</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>


        </div>
    </div>
</section>
