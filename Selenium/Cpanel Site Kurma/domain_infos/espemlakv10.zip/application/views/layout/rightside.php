<div class="box">
    <div class="box-header">
        Arama Kriterleri
    </div>
    <div class="box-body">
        <div class="filter">
            <form method="get" action="<?php echo clink('@search') ?>">
                <div class="form-group">
                    <label for="rightside-search-no">Emlak Kodu</label>
                    <input type="text" name="searchNo" id="rightside-search-no" class="form-control" value="<?php echo $this->input->get('searchNo') ?>" />
                </div>

                <div class="form-group">
                    <label for="rightside-search-kind">Emlak Türü</label>
                    <?php echo form_dropdown('searchKind', prepareForSelect($this->common->kinds(), 'id', 'title', ''), $this->input->get('searchKind'), 'id="rightside-search-kind" class="chosen-select-deselect" data-placeholder="Seçiniz"') ?>
                </div>

                <div class="form-group">
                    <label for="rightside-search-town">İlçe Seçin</label>
                    <?php echo form_dropdown('searchTown', prepareForSelect($this->common->towns(26), 'id', 'title', ''), $this->input->get('searchTown'), 'id="rightside-search-town" class="chosen-select-deselect" data-placeholder="Seçiniz"') ?>
                </div>

                <div class="form-group">
                    <label for="rightside-search-district">Semt Seçin</label>
                    <?php
                    $searchTown = $this->input->get('searchTown');

                    if (! empty($searchTown)) {
                        $districtOptions = prepareForSelect($this->common->districts($searchTown), 'id', 'title', '');
                    } else {
                        $districtOptions = array();
                    }

                    echo form_dropdown('searchDistrict', $districtOptions, $this->input->get('searchDistrict'), 'id="rightside-search-district" class="chosen-select-deselect" data-placeholder="İlçe Seçiniz"');
                    ?>
                </div>

                <div class="row">
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="rightside-search-price-min">Düşük Fiyat</label>
                            <input type="text" name="searchMinPrice" id="rightside-search-price-min" class="form-control numeric" value="<?php echo $this->input->get('searchMinPrice') ?>" />
                        </div>
                    </div>
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="rightside-search-price-max">Yüksek Fiyat</label>
                            <input type="text" name="searchMaxPrice" id="rightside-search-price-max" class="form-control numeric" value="<?php echo $this->input->get('searchMaxPrice') ?>" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="rightside-search-squaremeter-min">Metrekare Aralığı</label>
                            <input type="text" name="searchMinSquaremeter" id="rightside-search-squaremeter-min" class="form-control numeric" value="<?php echo $this->input->get('searchMinSquaremeter') ?>" />
                        </div>
                    </div>
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <input type="text" name="searchMaxSquaremeter" class="form-control numeric" value="<?php echo $this->input->get('searchMaxSquaremeter') ?>" />
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="rightside-search-room">Oda Sayısı</label>
                    <?php echo form_dropdown('searchRoom', prepareForSelect($this->common->rooms(), 'id', 'title', ''), $this->input->get('searchRoom'), 'id="rightside-search-room" class="chosen-select-deselect" data-placeholder="Seçiniz"') ?>
                </div>

                <div class="mascot text-right">
                    <button type="submit" class="btn btn-warning">ARAMA</button>
                </div>
                <p>
                    Tüm arama kriterlerinizi belirleyebilir en hızlı şekilde hayalinizdeki konuta ulaşabilir
                </p>

            </form>
        </div>
    </div>
</div>

<div class="estate-add hidden-xs">
    <a href="<?php echo clink('@estateinsert') ?>" title="Emlak Ekle">
        <img src="public/img/estate-add.png" alt="Emlak Ekle" />
    </a>
</div>


<div class="currency-rates">
    <?php $exchangeInformation = $this->common->exchangeInformation() ?>
    <div class="item">
        <img src="public/img/currency/dolar.png" alt="Dolar" />
        <span class="name">DOLAR</span>
        <span class="price"><?php echo money($exchangeInformation['usdBuy'], true) ?> TL</span>
        <span class="price"><?php echo money($exchangeInformation['usdSell'], true) ?> TL</span>
    </div>
    <div class="item">
        <img src="public/img/currency/euro.png" alt="Euro" />
        <span class="name">EURO</span>
        <span class="price"><?php echo money($exchangeInformation['euroBuy'], true) ?> TL</span>
        <span class="price"><?php echo money($exchangeInformation['euroSell'], true) ?> TL</span>
    </div>
    <div class="item">
        <img src="public/img/currency/sterlin.png" alt="Sterlin" />
        <span class="name">STERLIN</span>
        <span class="price"><?php echo money($exchangeInformation['sterlinBuy'], true) ?> TL</span>
        <span class="price"><?php echo money($exchangeInformation['sterlinSell'], true) ?> TL</span>
    </div>
</div>

<div class="wecallyou">
    <a id="wecallyou" href="<?php echo clink('@wecallyou') ?>" title="Biz Sizi Arayalım">
        <img src="public/img/wecallyou.png" alt="Biz Sizi Arayalım" />
    </a>
</div>