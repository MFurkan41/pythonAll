<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo $this->site->get('metaTitle') ?></title>
    <meta name="description" content="<?php echo $this->site->get('metaDescription') ?>">
    <meta name="keywords" content="<?php echo $this->site->get('metaKeywords') ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <base href="<?php echo base_url('/') ?>" />	

    <link rel="stylesheet" type="text/css" href="public/plugin/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="public/plugin/fancybox/jquery.fancybox.css" />
    <link rel="stylesheet" type="text/css" href="public/plugin/chosen/chosen.min.css" />
    <link rel="stylesheet" type="text/css" href="public/css/main.css" />
    <link rel="shortcut icon" href="public/img/favicon.png" />
    <?php if (isset($public['css'])): ?>
        <?php foreach ($public['css'] as $css): ?>
            <link rel="stylesheet" type="text/css" href="<?php echo $css ?>" />
        <?php endforeach; ?>
    <?php endif; ?>

    <script type="text/javascript" src="public/js/jquery.js"></script>
    <script type="text/javascript" src="public/js/jquery.bxslider.min.js"></script>
    <script type="text/javascript" src="public/js/jquery.maskedinput.min.js"></script>
    <script type="text/javascript" src="public/js/jquery.numeric.min.js"></script>
    <script type="text/javascript" src="public/js/bootstrap.filestyle.min.js"></script>
    <script type="text/javascript" src="public/plugin/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="public/plugin/fancybox/jquery.fancybox.js"></script>
    <script type="text/javascript" src="public/plugin/chosen/chosen.jquery.min.js"></script>

    <?php if (isset($public['js'])): ?>
        <?php foreach ($public['js'] as $js): ?>
            <script type="text/javascript" src="<?php echo $js ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    <script type="text/javascript" src="public/js/main.js"></script>


    <!-- HTML5 shim, for IE6-8 support of HTML5 elements html5shiv.js -->
    <!--[if lt IE 9]><script src="public/js/html5shiv.js'"></script><![endif]-->

    <link rel="canonical" href="<?php echo current_url() ?>" />

    <?php if ($ogType = $this->site->get('ogType')): ?>
        <meta property="og:type" content="<?php echo $ogType ?>" />
    <?php endif; ?>
    <?php if ($ogTitle = $this->site->get('ogTitle')): ?>
        <meta property="og:title" content="<?php echo htmlspecialchars($ogTitle) ?>" />
    <?php endif; ?>
    <?php if ($ogDescription = $this->site->get('ogDescription')): ?>
        <meta property="og:description" content="<?php echo htmlspecialchars($ogDescription) ?>" />
    <?php endif; ?>
    <?php if ($ogImage = $this->site->get('ogImage')): ?>
		<meta name="image" content="<?php echo base_url('/').$ogImage ?>" />
		<link rel="image_src" href="<?php echo base_url('/').$ogImage ?>" />
        <meta property="og:image" content="<?php echo base_url('/').$ogImage ?>"/>
    <?php endif; ?>

    <meta property="og:url" content="<?php echo current_url() ?>"/>

    <?php echo $this->site->get('customMeta') ?>


    <?php if (isset($this->banner)): ?>
        <link rel="stylesheet" href="public/plugin/layerslider/css/layerslider.css" type="text/css">
        <script src="public/plugin/layerslider/js/greensock.js" type="text/javascript"></script>
        <script src="public/plugin/layerslider/js/layerslider.transitions.js" type="text/javascript"></script>
        <script src="public/plugin/layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#layerslider').layerSlider({
                    skin: 'fullwidth',
                    skinsPath: 'public/plugin/layerslider/skins/',
                    navStartStop: false,
                    navButtons: false,
                    layersContainer : 1140
                });
            });
        </script>
    <?php endif; ?>
</head>
<body>

<div id="fb-root"></div>
<script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/tr_TR/sdk.js#xfbml=1&appId=116061301815856&version=v2.0";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
</script>

<header id="header">
    <div class="container relative">

        <div class="socials">
            <?php if ($socialLink = $this->site->get('socialFacebook')): ?>
                <a class="facebook" href="<?php echo $socialLink ?>" target="_blank" title="Facebook"></a>
            <?php endif; ?>
            <?php if ($socialLink = $this->site->get('socialTwitter')): ?>
                <a class="twitter" href="<?php echo $socialLink ?>" target="_blank" title="Twitter"></a>
            <?php endif; ?>
            <?php if ($socialLink = $this->site->get('socialGoogle')): ?>
                <a class="google" href="<?php echo $socialLink ?>" target="_blank" title="Google+"></a>
            <?php endif; ?>
        </div>

        <nav class="navbar navbar-default">

            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="./"></a>
            </div>


            <div class="collapse navbar-collapse" id="navbar-collapse">

                <ul class="nav navbar-nav navbar-right">
                    <?php foreach ($this->menu->get('header') as $menu): ?>
                        <li <?php echo ! empty($menu->childs) ? 'class="dropdown"':'' ?>>
                            <a href="<?php echo clink($menu->link) ?>" title="<?php echo $menu->hint ?>" <?php echo ! empty($menu->childs) ? 'class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"':'' ?>><?php echo $menu->title ?> <?php echo ! empty($menu->childs) ? '<span class="caret">':'' ?></a>
                            <?php if (! empty($menu->childs)): ?>
                                <ul class="dropdown-menu">
                                    <?php foreach ($menu->childs as $child): ?>
                                        <li><a href="<?php echo clink($child->link) ?>" title="<?php echo $child->hint ?>"><?php echo $child->title ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>

            </div>
        </nav>
    </div>
</header>

<?php if (isset($this->banner)): ?>
<section id="banner" class="visible-lg">
    <div id="layerslider" style="width: 100%; height: 500px;">
        <?php foreach ($this->banner->all() as $banner): ?>
            <div class="ls-slide" data-ls="slidedelay: <?php echo $banner->delay ?>; <?php echo $banner->transition ?>">
                
                <img class="ls-bg" src="public/upload/banner/<?php echo $banner->image ?>" alt="<?php echo $banner->title ?>" />

                <?php if (! empty($banner->text)): ?>
                    <?php
                    $top = 100;
                    $delayin = 200;
                    ?>

                    <?php foreach (explode("\n", $banner->text, 2) as $text): ?>
                        <div class="ls-l text" style="top: <?php echo $top ?>px; left: 0;" data-ls="delayin: <?php echo $delayin ?>; offsetxin: -150; offsetxout: 150;">
                            <span><?php echo $text ?></span>
                        </div>
                        <?php
                        $top += 71;
                        $delayin += 100;
                        ?>
                    <?php endforeach; ?>
                <?php endif; ?>
				
				<?php echo !empty($banner->link) ? '<a class="ls-link" href="'. $banner->link .'" title="'. $banner->title .'"></a>':'' ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="search container">
        <div class="search-box">
            <form method="get" action="<?php echo clink('@search') ?>">
                <div class="form-group">
                    <label for="banner-search-no">Emlak Kodu:</label>
                    <input type="text" name="searchNo" id="banner-search-no" class="form-control input-sm" />
                </div>
                <div class="form-group">
                    <label for="banner-search-kind">Emlak Türü:</label>
                    <select name="searchKind" id="banner-search-kind" class="chosen-select-deselect" data-placeholder="Seçiniz">
                        <?php foreach (prepareForSelect($this->common->kinds(), 'id', 'title', '') as $value => $label): ?>
                            <option value="<?php echo $value ?>"><?php echo $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="banner-search-town">İlçe Seçin:</label>
                    <select name="searchTown" id="banner-search-town" class="chosen-select-deselect" data-placeholder="Seçiniz">
                        <?php foreach (prepareForSelect($this->common->towns(26), 'id', 'title', '') as $value => $label): ?>
                            <option value="<?php echo $value ?>"><?php echo $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="banner-search-district">Semt Seçin:</label>
                    <select name="searchDistrict" id="banner-search-district" class="chosen-select-deselect" data-placeholder="İlçe Seçiniz">
                    </select>
                </div>



                <div class="row">
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="banner-search-price-min">En Düşük Fiyat:</label>
                            <input type="text" name="searchMinPrice" id="banner-search-price-min" class="form-control input-sm numeric" />
                        </div>
                    </div>
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="banner-search-price-max">En Yüksek Fiyat:</label>
                            <input type="text" name="searchMaxPrice" id="banner-search-price-max" class="form-control input-sm numeric" />
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="banner-search-squaremeter-min">Metrekare Aralığı:</label>
                            <input type="text" name="searchMinSquaremeter" id="banner-search-squaremeter-min" class="form-control input-sm numeric" />
                        </div>
                    </div>
                    <div class="column col-xs-6">
                        <div class="form-group">
                            <label for="banner-search-squaremeter-max">&nbsp;</label>
                            <input type="text" name="searchMaxSquaremeter" id="banner-search-squaremeter-max" class="form-control input-sm numeric" />
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <label for="banner-search-room">Oda Sayısı:</label>
                    <select name="searchRoom" id="banner-search-room" class="chosen-select-deselect" data-placeholder="Seçiniz">
                        <?php foreach (prepareForSelect($this->common->rooms(), 'id', 'title', '') as $value => $label): ?>
                            <option value="<?php echo $value ?>"><?php echo $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-button">
                    <button type="submit" class="btn btn-warning">ARAMA</button>
                </div>

            </form>
        </div>
    </div>
</section>
<?php endif; ?>

<?php $this->view($view, $data); ?>

<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="column col-md-8">
                <div class="row">
                    <?php foreach ($this->menu->get('footer') as $menu): ?>
                        <div class="column col-sm-3">
                            <h3><?php echo $menu->title ?></h3>
                            <ul>
                                <?php foreach ($menu->childs as $child): ?>
                                    <li><a href="<?php echo clink($child->link) ?>" title="<?php echo $child->hint ?>"><?php echo $child->title ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="column col-md-4">
                <div class="address row">
                    <div class="column col-xs-2 text-center"><span class="glyphicon glyphicon-map-marker"></span></div>
                    <div class="column col-xs-10"><?php echo $this->site->get('footerAddress') ?></div>
                </div>

                <div class="address row">
                    <div class="column col-xs-2 text-center"><span class="glyphicon glyphicon-earphone"></span></div>
                    <div class="column col-xs-10"><?php echo $this->site->get('footerPhone') ?></div>
                </div>

                <div class="address row">
                    <div class="column col-xs-2 text-center"><span class="glyphicon glyphicon-envelope"></span></div>
                    <div class="column col-xs-10"><?php echo $this->site->get('footerEmail') ?></div>
                </div>
            </div>


        </div>
    </div>
</footer>


<div id="modal-wecallyou" class="modal" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog" style="width: 350px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><strong>Biz Sizi Arayalım</strong></h4>
            </div>
            <div class="modal-body">
                <p>Telefon numaranızı bırakın hemen sizinle irtibata geçelim.</p>
                <div class="form-group">
                    <label>Adınız Soyadınız</label>
                    <input type="text" name="fullname" class="form-control" required="required" />
                </div>

                <div class="form-group">
                    <label>Telefon Numaranız</label>
                    <input type="text" name="phone" class="form-control mask-phone" required="required" />
                </div>

                <div class="alert alert-danger hide"></div>

            </div>
            <div class="modal-footer">
                <button id="wecallyou-button" type="submit" class="btn btn-success">Gönder</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>
