
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">
            <?php if (! empty($content->parent->childs)): ?>
                <div class="box">
                    <div class="box-header"><?php echo $content->parent->title ?></div>
                    <div class="box-body">
                        <ul class="navigation">
                            <?php foreach ($content->parent->childs as $child): ?>
                                <li class="<?php echo $content->id === $child->id ? 'active':'' ?>">
                                    <a href="<?php echo clink(array('@content', $child->slug, $child->id)) ?>" title="<?php echo $child->title ?>"><?php echo $child->title ?>
                                        <span class="pull-right glyphicon glyphicon-chevron-right"></span>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (! empty($content->childs)): ?>
                <div class="box">
                    <div class="box-header"><?php echo $content->title ?></div>
                    <div class="box-body">
                        <ul class="navigation">
                            <?php foreach ($content->childs as $child): ?>
                                <li><a href="<?php echo clink(array('@content', $child->slug, $child->id)) ?>" title="<?php echo $child->title ?>"><?php echo $child->title ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>


            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $content->title ?>
                </div>

                <div class="box-body">
                    <?php echo $content->detail ?>

                    <p>
                        <br />
                        <a class="btn btn-primary btn-sm" href="javascript:history.back();"><span class="glyphicon glyphicon-circle-arrow-left"></span> Geri Dön</a>
                    </p>

                    <div class="share-box">
                        <p><strong>Sosyal Medyada Paylaşın</strong></p>
                        <a class="facebook" href="http://facebook.com/sharer.php?u=<?php echo current_url() ?>" title="Facebook'ta Paylaş">Facebook'ta Paylaş</a>
                        <a class="twitter" href="https://twitter.com/share?url=<?php echo current_url() ?>&text=<?php echo htmlspecialchars($content->title) ?>" title="Twitter'da Paylaş">Twitter'da Paylaş</a>
                        <a class="google" href="https://plus.google.com/share?url=<?php echo current_url() ?>" title="Google+'ta Paylaş">Google+'ta Paylaş</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
