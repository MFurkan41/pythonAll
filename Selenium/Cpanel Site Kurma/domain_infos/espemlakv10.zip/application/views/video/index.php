
<section id="main" class="container">
    <div class="row">
        <div class="column col-sm-6 col-md-3">

            <?php $this->view('layout/rightside') ?>

        </div>



        <div class="column col-sm-6 col-md-9">

            <div class="box">
                <div class="box-header">
                    <?php echo $this->module->arguments->title ?>
                </div>

                <div class="videos box-body">
                    <div class="row">

                        <?php foreach ($videos as $item): ?>
                            <div class="column col-md-6">
                                <div class="video">
                                    <div class="image">
                                        <a class="fancybox fancybox.iframe" href="//www.youtube-nocookie.com/embed/<?php echo $item->video ?>?rel=0" title="<?php echo $item->title ?>">
                                            <img src="<?php echo uploadPath($item->image, 'video') ?>" alt="<?php echo $item->title ?>" />
                                        </a>
                                    </div>
                                    <div class="detail">
                                        <div class="title"><a class="fancybox-video" href="//www.youtube-nocookie.com/embed/<?php echo $item->video ?>?rel=0"><?php echo $item->title ?></a></div>
                                        <div class="summary"><?php echo $item->summary ?></div>
                                        <div class="play"><a class="fancybox-video" href="//www.youtube-nocookie.com/embed/<?php echo $item->video ?>?rel=0">OYNAT</a></div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </div>

                    <div class="text-center">
                        <?php if (! empty($pagination)): ?>
                            <?php echo $pagination ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


        </div>
    </div>
</section>
