<div class="container">

    <section id="content">
        <div class="panel">
            <div class="panel-header"><?php echo $gallery->title ?></div>
            <div class="panel-body clearfix">

                <div class="gallery-list clearfix">
                    <?php foreach ($gallery->images as $item): ?>
                        <div class="item">
                            <a class="fancybox" rel="gallery" href="<?php echo uploadPath($item->image, 'gallery/normal') ?>">
                                <img src="<?php echo uploadPath($item->image, 'gallery/thumb') ?>" />
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="buttons">
                    <a href="javascript:history.back();">Geri Dön</a>
                    <a href="<?php echo clink('@gallery') ?>">Tüm Galeriler</a>
                </div>
            </div>
        </div>
    </section>


</div>
