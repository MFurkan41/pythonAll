<?php


class Partner extends  CI_Model
{

    public function all($limit = null, $offset = null)
    {
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->from('partners')
            ->order_by('order', 'asc')
            ->order_by('id', 'desc')
            ->get()
            ->result();
    }


}