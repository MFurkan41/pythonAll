<?php


class Estate extends  CI_Model
{

    public function findId($id)
    {
        return $this->db
            ->select('estates.*,
                cities.title cityTitle,
                towns.title townTitle,
                districts.title districtTitle,
                kinds.title kindTitle,
                types.title typeTitle,
                rooms.title roomTitle,
                floors.title floorTitle,
                building_ages.title buildingAgeTitle,
                heatings.title heatingTitle,
                usage_statuses.title usageStatusTitle,
                '
            )
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->join('rooms', 'rooms.id = estates.roomId', 'left')
            ->join('floors', 'floors.id = estates.floorId', 'left')
            ->join('building_ages', 'building_ages.id = estates.buildingAgeId', 'left')
            ->join('heatings', 'heatings.id = estates.heatingId', 'left')
            ->join('usage_statuses', 'usage_statuses.id = estates.usageStatusId', 'left')
            ->where('estates.id', $id)
            ->get()
            ->row();
    }


    public function images($estate)
    {
        if (! isset($estate->images)) {
            $estate->images = $this->db
                ->from('estate_images')
                ->where('estateId', $estate->id)
                ->order_by('order', 'asc')
                ->order_by('id', 'asc')
                ->get()
                ->result();
        }
    }


    public function properties($estate)
    {
        if (! isset($estate->properties)) {
            $estate->properties = $this->db
                ->from('properties')
                ->join('estate_properties', 'estate_properties.propertyId = properties.id')
                ->where('estate_properties.estateId', $estate->id)
                ->order_by('properties.order', 'asc')
                ->order_by('properties.id', 'asc')
                ->get()
                ->result();
        }
    }



    public function count($status)
    {
        return $this->db
            ->from('estates')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', $status)
            ->count_all_results();
    }


    public function all($status, $limit = null, $offset = null)
    {
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->select('estates.id, estates.estateStatus, districts.title districtTitle, types.title typeTitle, estates.price, estates.image')
            ->from('estates')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', $status)
            ->order_by('estates.updateDate', 'desc')
            ->get()
            ->result();
    }



    public function lastEstates($status, $limit)
    {
        return $this->db
            ->select('estates.id, estates.estateStatus, districts.title districtTitle, types.title typeTitle, estates.price, estates.image')
            ->from('estates')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', $status)
            ->order_by('estates.updateDate', 'desc')
            ->limit($limit)
            ->get()
            ->result();
    }


    public function lastRentEstates()
    {
        return $this->lastEstates('Kiralık', 4);
    }

    public function lastSaleEstates()
    {
        return $this->lastEstates('Satılık', 8);
    }



    public function newContactRequest($estate)
    {
        $data = array(
            'estateId' => $estate->id,
            'fullname' => $this->input->post('fullname'),
            'phone' => $this->input->post('phone'),
            'message' => $this->input->post('message'),
            'date' => $this->date->set()->mysqlDatetime(),
            'ip' => $this->input->ip_address()
        );

        $this->db->insert('estate_contacts', $data);
        $success = $this->db->insert_id();

        $data['estate'] = $estate;


        if ($success && $this->module->arguments->notification == true) {
            $this->load->library('email');
            $this->email->initialize(array(
                'smtp_host' => $this->site->get('smtpHost'),
                'smtp_port' => $this->site->get('smtpPort'),
                'smtp_user' => $this->site->get('smtpUser'),
                'smtp_pass' => $this->site->get('smtpPass'),
            ));

            $this->email->from($this->module->arguments->notificationMail, htmlspecialchars($this->input->post('fullname')));
            $this->email->to($this->module->arguments->notificationMail);
            $this->email->subject('Emlak İletişim Formu Bildirimi');
            $this->email->message($this->load->view('estate/mail', $data, true));
            $this->email->send();
        }

        return $success;
    }



    public function checkNo($no)
    {
        return $this->db
            ->from('estates')
            ->where('estates.no', $no)
            ->get()
            ->row();
    }


    public function filter($limit = null, $offset = null)
    {
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        if ($this->input->get('searchKind')) {
            $this->db->where('estates.kindId', $this->input->get('searchKind'));
        }

        if ($this->input->get('searchTown')) {
            $this->db->where('estates.townId', $this->input->get('searchTown'));
        }

        if ($this->input->get('searchDistrict')) {
            $this->db->where('estates.districtId', $this->input->get('searchDistrict'));
        }

        if ($this->input->get('searchMinPrice')) {
            $this->db->where('estates.price >=', $this->input->get('searchMinPrice'));
        }

        if ($this->input->get('searchMaxPrice')) {
            $this->db->where('estates.price <=', $this->input->get('searchMaxPrice'));
        }

        if ($this->input->get('searchMinSquaremeter')) {
            $this->db->where('estates.squaremeter >=', $this->input->get('searchMinSquaremeter'));
        }

        if ($this->input->get('searchMaxSquaremeter')) {
            $this->db->where('estates.squaremeter <=', $this->input->get('searchMaxSquaremeter'));
        }

        if ($this->input->get('searchRoom')) {
            $this->db->where('estates.roomId', $this->input->get('searchRoom'));
        }


        $sortPrice = $this->input->get('sortPrice');

        if ($sortPrice == 'asc' || $sortPrice = 'desc') {
            $this->db->order_by('estates.price', $sortPrice);
        } else {
            $this->db->order_by('estates.price', 'desc');
        }

        return $this->db
            ->select('estates.id, estates.estateStatus, districts.title districtTitle, types.title typeTitle, estates.price, estates.image')
            ->from('estates')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->get()
            ->result();
    }




    public function filterCount()
    {

        if ($this->input->get('searchKind')) {
            $this->db->where('estates.kindId', $this->input->get('searchKind'));
        }

        if ($this->input->get('searchTown')) {
            $this->db->where('estates.townId', $this->input->get('searchTown'));
        }

        if ($this->input->get('searchDistrict')) {
            $this->db->where('estates.districtId', $this->input->get('searchDistrict'));
        }

        if ($this->input->get('searchMinPrice')) {
            $this->db->where('estates.price >=', $this->input->get('searchMinPrice'));
        }

        if ($this->input->get('searchMaxPrice')) {
            $this->db->where('estates.price <=', $this->input->get('searchMaxPrice'));
        }

        if ($this->input->get('searchMinSquaremeter')) {
            $this->db->where('estates.squaremeter >=', $this->input->get('searchMinSquaremeter'));
        }

        if ($this->input->get('searchMaxSquaremeter')) {
            $this->db->where('estates.squaremeter <=', $this->input->get('searchMaxSquaremeter'));
        }

        if ($this->input->get('searchRoom')) {
            $this->db->where('estates.roomId', $this->input->get('searchRoom'));
        }



        return $this->db
            ->from('estates')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->count_all_results();
    }



    public function insert($data)
    {
        $posts = $this->input->post();
        $data = array(
            'fullname' => $this->input->post('insertFullname'),
            'email' => $this->input->post('insertEmail'),
            'phone' => $this->input->post('insertPhone'),
            'message' => $this->input->post('insertMessage'),
            'cityId' => $this->input->post('insertCity'),
            'townId' => $this->input->post('insertTown'),
            'districtId' => $this->input->post('insertDistrict'),
            'estateStatus' => $this->input->post('insertStatus'),
            'kindId' => $this->input->post('insertKind'),
            'typeId' => $this->input->post('insertType'),
            'price' => $this->input->post('insertPrice'),
            'image' => $data['name'],
            'description' => $this->input->post('insertDescription'),
            'roomId' => empty($posts['insertRoom']) ? null : $posts['insertRoom'],
            'bath' => $this->input->post('insertBath'),
            'squaremeter' => $this->input->post('insertSquaremeter'),
            'floorId' =>  empty($posts['insertFloor']) ? null : $posts['insertFloor'],
            'storeyCount' => $this->input->post('insertStoreyCount'),
            'buildingAgeId' => empty($posts['insertBuildingAge']) ? null : $posts['insertBuildingAge'],
            'heatingId' => $this->input->post('insertHeating'),
            'usageStatusId' => empty($posts['insertUsageStatus']) ? null : $posts['insertUsageStatus'],
            'properties' => json_encode($this->input->post('properties')),
            'date' => $this->date->set()->mysqlDatetime(),
            'ip' => $this->input->ip_address()
        );

        $this->db->insert('estate_inserts', $data);
        $success = $this->db->insert_id();


        if ($success && $this->module->arguments->notification == true) {
            $this->load->library('email');
            $this->email->initialize(array(
                'smtp_host' => $this->site->get('smtpHost'),
                'smtp_port' => $this->site->get('smtpPort'),
                'smtp_user' => $this->site->get('smtpUser'),
                'smtp_pass' => $this->site->get('smtpPass'),
            ));

            $this->email->from($this->input->post('email'), htmlspecialchars($this->input->post('fullname')));
            $this->email->to($this->module->arguments->notificationMail);
            $this->email->subject('İlan Ekleme Bildirimi');
            $this->email->message($this->load->view('estate/insertmail', $data, true));
            $this->email->send();
        }

        return $success;
    }




    public function increaseView($estate)
    {

        $views = $this->session->userdata('estate-view');

        if (! $views) {
            $views = array();
        }

        if (! in_array($estate->id, $views)) {
            $this->db
                ->where('id', $estate->id)
                ->set('views', 'views + 1', false)
                ->update('estates');

            $views[] = $estate->id;
            $estate->views = $estate->views + 1;

            $this->session->set_userdata('estate-view', $views);
        }

    }

}