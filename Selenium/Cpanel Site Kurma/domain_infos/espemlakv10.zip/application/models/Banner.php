<?php


class Banner extends CI_Model
{

    public function all()
    {
        return $this->db
            ->from('banners')
            ->where('language', $this->language)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

}