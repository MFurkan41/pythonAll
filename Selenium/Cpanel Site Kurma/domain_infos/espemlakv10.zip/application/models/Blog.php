<?php


class Blog extends  CI_Model
{

    public function posts($limit = null, $offset = null)
    {
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->select('blog_posts.*, blog_categories.title categoryTitle, blog_categories.slug categorySlug')
            ->from('blog_posts')
            ->join('blog_categories', 'blog_categories.id = blog_posts.categoryId')
            ->where('blog_posts.language', $this->language)
            ->order_by('blog_posts.id', 'desc')
            ->get()
            ->result();
    }

    public function postsWithFixed($limit)
    {

        /*
        $fixed = $this->db
            ->select('blog_posts.*, blog_categories.title categoryTitle, blog_categories.slug categorySlug')
            ->from('blog_posts')
            ->join('blog_categories', 'blog_categories.id = blog_posts.categoryId')
            ->where('blog_categories.fixed', 1)
            ->where('blog_posts.language', $this->language)
            ->order_by('blog_posts.id', 'desc')
            ->limit(1)
            ->get()
            ->result();

        if ($fixed) {
            $limit = $limit - 1;
        }

        $results = $this->db
            ->select('blog_posts.*, blog_categories.title categoryTitle, blog_categories.slug categorySlug')
            ->from('blog_posts')
            ->join('blog_categories', 'blog_categories.id = blog_posts.categoryId')
            ->where('blog_categories.fixed',  0)
            ->where('blog_posts.language', $this->language)
            ->order_by('blog_posts.id', 'desc')
            ->limit($limit)
            ->get()
            ->result();


        return array_merge($fixed, $results);
        */
        $categories = $this->categories();
        $results = array();



        foreach ($categories as $category) {
            if (count($results) === $limit) {
                break;
            }

            $result = $this->db
                ->select('blog_posts.*, blog_categories.title categoryTitle, blog_categories.slug categorySlug')
                ->from('blog_posts')
                ->join('blog_categories', 'blog_categories.id = blog_posts.categoryId')
                ->where('blog_posts.language', $this->language)
                ->where('blog_posts.categoryId', $category->id)
                ->order_by('blog_posts.id', 'desc')
                ->limit(1)
                ->get()
                ->row();

            if ($result) {
                $results[] = $result;
            }
        }




        return $results;

    }

    public function postCount()
    {
        return $this->db
            ->from('blog_posts')
            ->where('language', $this->language)
            ->count_all_results();
    }


    public function findPostId($id)
    {
        return $this->db
            ->from('blog_posts')
            ->where('id', $id)
            ->where('language', $this->language)
            ->get()
            ->row();

    }


    public function findCategoryId($id)
    {
        return $this->db
            ->from('blog_categories')
            ->where('id', $id)
            ->where('language', $this->language)
            ->get()
            ->row();

    }


    public function categories($limit = null)
    {
        if (! empty($limit)) {
            $this->db->limit($limit);
        }
        return $this->db
            ->from('blog_categories')
            ->where('language', $this->language)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function categoryPosts($category, $limit = null, $offset = null)
    {
        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->from('blog_posts')
            ->where('language', $this->language)
            ->where('categoryId', $category->id)
            ->order_by('id', 'desc')
            ->get()
            ->result();
    }

    public function categoryPostCount($category)
    {
        return $this->db
            ->from('blog_posts')
            ->where('language', $this->language)
            ->where('categoryId', $category->id)
            ->count_all_results();
    }





}