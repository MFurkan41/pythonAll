<?php


class Showcase extends CI_Model
{

    public function all()
    {
        $results = $this->db
            ->select('showcases.*, estates.image image, estates.price price, districts.title districtTitle, types.title typeTitle')
            ->from('showcases')
            ->join('estates', "estates.id = showcases.estateId")
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where('showcases.language', $this->language)
            ->order_by('showcases.order', 'asc')
            ->order_by('showcases.id', 'asc')
            ->get()
            ->result();


        $count = count($results);

        if ($count < 3 || $count == 4) {
            return false;
        }

        $items = array();
        $index = 1;

        foreach ($results as $result) {
            if ($index > 5) {
                $index = 1;
            }

            $items[$index][] = $result;
            $index++;
        }

        return $items;
    }

}