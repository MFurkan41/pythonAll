<?php

$lang['facebook-comments'] = 'FACEBOOK YORUMLARI';
$lang['customer-services'] = 'Müşteri Hizmetleri';