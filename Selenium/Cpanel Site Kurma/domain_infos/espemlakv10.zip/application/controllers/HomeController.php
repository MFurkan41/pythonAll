<?php


class HomeController  extends CI_Controller
{

    public function index()
    {
        $this->load->model('banner');
        $this->load->model('estate');
        $this->load->model('partner');
        $this->load->model('blog');
        $this->load->model('showcase');

        $showcaseStyle = array(
            '1' => 'showcase-large showcase-1',
            '2' => 'showcase-small showcase-2',
            '3' => 'showcase-small showcase-3',
            '4' => 'showcase-large showcase-4',
            '5' => 'showcase-medium showcase-5'
        );

        $this->load->view('layout/master', array(
            'view' => 'home',
            'data' => array(
                'lastRentEstates' => $this->estate->lastRentEstates(),
                'lastSaleEstates' => $this->estate->lastSaleEstates(),
                'blogs' => $this->blog->postsWithFixed(4),
                'showcases' => $this->showcase->all(),
                'showcaseStyle' => $showcaseStyle,
                'partners' => $this->partner->all()
            )
        ));
    }




} 