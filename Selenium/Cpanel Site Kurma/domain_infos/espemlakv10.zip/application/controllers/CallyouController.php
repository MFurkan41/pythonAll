<?php


class CallyouController  extends CI_Controller
{
    public $module = 'callyou';


    public function index()
    {
        $this->load->model('callyou');
        $json = array('success' => false, 'message' => '');

        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('fullname', 'Lütfen Adınızı ve Soyadınızı yazınız.', 'required');
            $this->form_validation->set_rules('phone', 'Lütfen Telefon Numaranızı yazınız.', 'required');

            if ($this->form_validation->run() == true) {
                $success = $this->callyou->insert();

                if ($success) {
                    $json['success'] = true;
                    $json['message'] = 'Talebiniz kaydedildi. En kısa zamanda sizinle iletişime geçilecek.';
                }
            } else {
                $json['message'] = $this->form_validation->error_string('<div>&bull; ', '</div>');
            }
        }

        echo json_encode($json);
    }



} 