<?php


class BlogController  extends CI_Controller
{

    public $module = 'blogpost';



    public function index()
    {
        $this->load->model('blog');

        $posts = array();
        $pagination = null;
        $postCount = $this->blog->postCount();

        if ($postCount > 0) {
            $config = array(
                'base_url' => clink(array('@blog')),
                'total_rows' => $postCount,
                'per_page' => 9
            );

            $this->load->library('pagination');
            $this->pagination->initialize($config);


            $posts = $this->blog->posts($this->pagination->per_page, $this->pagination->offset);
            $pagination = $this->pagination->create_links();
        }


        $this->load->view('layout/master', array(
            'view' => 'blog/index',
            'data' => array(
                'posts' => $posts,
                'categories' => $this->blog->categories(),
                'pagination' => $pagination,
            )
        ));
    }



    public function category($id)
    {
        $this->load->model('blog');

        if (! $category = $this->blog->findCategoryId($id)) {
            show_404();
        }

        $posts = array();
        $pagination = null;
        $postCount = $this->blog->categoryPostCount($category);

        if ($postCount > 0) {
            $config = array(
                'base_url' => clink(array('@blogcategory', $category->slug, $category->id)),
                'total_rows' => $postCount,
                'per_page' => 9
            );

            $this->load->library('pagination');
            $this->pagination->initialize($config);


            $posts = $this->blog->categoryPosts($category, $this->pagination->per_page, $this->pagination->offset);
            $pagination = $this->pagination->create_links();
        }


        $this->site->set('metaTitle', !empty($category->metaTitle) ? $category->metaTitle : $category->title, ' - ');
        $this->site->set('metaDescription', $category->metaDescription);
        $this->site->set('metaKeywords', $category->metaKeywords);


        $this->load->view('layout/master', array(
            'view' => 'blog/category',
            'data' => array(
                'posts' => $posts,
                'category' => $category,
                'categories' => $this->blog->categories(),
                'pagination' => $pagination,
            )
        ));
    }



    public function post($id)
    {
        $this->load->model('blog');

        if (! $post = $this->blog->findPostId($id)) {
            show_404();
        }

        $category = $this->blog->findCategoryId($post->categoryId);

        $this->site->set('metaTitle', !empty($post->metaTitle) ? $post->metaTitle : $post->title, ' - ');
        $this->site->set('metaDescription', !empty($post->metaDescription) ? $post->metaDescription : $post->summary);
        $this->site->set('metaKeywords', $post->metaKeywords);


        $this->site->set('ogType', 'article');
        $this->site->set('ogTitle', $post->title);
        $this->site->set('ogDescription', !empty($post->metaDescription) ? $post->metaDescription : $post->summary);

        if (! empty($post->image)) {
            $this->site->set('ogImage', uploadPath($post->image, 'blog'));
        }

        $this->load->view('layout/master', array(
            'view' => 'blog/post',
            'data' => array(
                'post' => $post,
                'category' => $category,
                'categories' => $this->blog->categories()
            )
        ));
    }




} 