<?php


class Transport  extends CI_Controller
{

    public function index()
    {
        die();

        /*

        $estateStatus = array(
            '1' => 'Kiralık',
            '2' => 'Satılık',
            '3' => 'Kiralandı',
            '4' => 'Satıldı',
            '5' => 'Slindi'
        );

        $kindAndType = array(
            '4' => array('kind' => '1', 'type' => '1'),
            '12' => array('kind' => '1', 'type' => '6'),
            '11' => array('kind' => '1', 'type' => '5'),
            '10' => array('kind' => '1', 'type' => '4'),
            '18' => array('kind' => '1', 'type' => '7'),
            '20' => array('kind' => '1', 'type' => '8'),
            '27' => array('kind' => '1', 'type' => '9'),
            '6' => array('kind' => '1', 'type' => '3'),
            '5' => array('kind' => '1', 'type' => '2'),
            '34' => array('kind' => '2', 'type' => '15'),
            '14' => array('kind' => '2', 'type' => '14'),
            '13' => array('kind' => '2', 'type' => '13'),
            '7' => array('kind' => '2', 'type' => '10'),
            '9' => array('kind' => '2', 'type' => '12'),
            '8' => array('kind' => '2', 'type' => '11'),
            '15' => array('kind' => '3', 'type' => '16'),
            '16' => array('kind' => '3', 'type' => '17'),
            '19' => array('kind' => '3', 'type' => '19'),
            '17' => array('kind' => '3', 'type' => '18'),
            '22' => array('kind' => '4', 'type' => '20'),
            '24' => array('kind' => '4', 'type' => '22'),
            '25' => array('kind' => '4', 'type' => '21'),
            '23' => array('kind' => '4', 'type' => '22'),
            '29' => array('kind' => '4', 'type' => '23'),
            '31' => array('kind' => '7', 'type' => '24'),
        );

        $heating = array(
            '0' => '0',
            '1' => '1',
            '2' => '2',
            '3' => '3',
            '4' => '4',
            '5' => '5',
            '6' => '6',
            '7' => '7',
            '9' => '8',
            '10' => '9',
            '11' => '10',
            '12' => '11',
            '13' => '12',
            '14' => '15',
            '15' => '14',
            '16' => '15',
            '17' => '15',
            '18' => '16',
            '19' => '17',
        );

        $usageStatus = array(
            '0' => '',
            '1' => 'Mal Sahibi Oturuyor',
            '2' => 'Kiracı Oturuyor',
            '3' => 'Boş Durumda',
            '4' => 'Müstakil',
        );


        $estates = array();
        $results = $this->db
            ->from('anahtar.emlaklar')
            ->where('anahtar.emlaklar.durumID <=', 2)
            ->where('anahtar.emlaklar.onay', 1)
            ->where('anahtar.emlaklar.emlakID >=', 150)
            ->order_by('anahtar.emlaklar.emlakID', 'asc')
            ->get()
            ->result();


        foreach ($results as $result) {

            $estate = new stdClass();

            $town = $this->db
                ->select('towns.id')
                ->from('towns')
                ->join('anahtar.kategoriler', 'anahtar.kategoriler.kat_adi = towns.title')
                ->where("anahtar.kategoriler.kat_no = {$result->ilce}")
                ->get()
                ->row();

            $district = $this->db
                ->select('districts.id')
                ->from('districts')
                ->join('anahtar.kategoriler', 'anahtar.kategoriler.kat_adi = districts.title')
                ->where("anahtar.kategoriler.kat_no = {$result->semt}")
                ->get()
                ->row();

            $storey = $this->db
                ->select('anahtar.kat.katAdi title')
                ->from('anahtar.kat')
                ->where("anahtar.kat.katID = {$result->katID}")
                ->get()
                ->row();




            $properties = explode(',', $result->detay);

            $props = $this->db
                ->select('properties.id')
                ->from('anahtar.detay')
                ->join('properties', 'properties.id = anahtar.detay.detaySira')
                ->where_in('anahtar.detay.detayID', $properties)
                ->get()
                ->result();




            $estate->no = $result->emlakID;
            $estate->cityId = $result->il;
            $estate->townId = ! $town ? 1 : $town->id;
            $estate->districtId = ! $district ? 1 : $district->id;
            $estate->estateStatus = $estateStatus[$result->durumID];
            $estate->kindID = $kindAndType[$result->emlakturID]['kind'];
            $estate->typeID = $kindAndType[$result->emlakturID]['type'];
            $estate->price = $result->fiyat;
            $estate->description = $result->aciklama;
            $estate->room = $result->oda;
            $estate->saloon = $result->salon;
            $estate->bath = $result->banyo;
            $estate->squaremeter = $result->alan;
            $estate->storey = ! $storey ? '' : $storey->title;
            $estate->storeyCount = $result->binakat;
            $estate->buildingAge = $result->binayas;
            $estate->heatingId = $heating[$result->isinmaID];
            $estate->usageStatus = $usageStatus[$result->kullanmaID];
            $estate->date = $this->date->set()->mysqlDatetime();
            $estate->image = "{$estate->no}_1.jpg";



            $this->db->insert('estates', $estate);
            $insertId = $this->db->insert_id();

            if ($insertId > 0) {
                foreach ($props as $p) {
                    $this->db->insert('estate_properties', array(
                        'estateId' => $insertId,
                        'propertyId' => $p->id
                    ));
                }
            }



            $this->load->library('SimpleImage');
            $image = $this->simpleimage->load("buyuk/{$estate->no}_1.jpg");
            $image->resize(600, 450);
            $image->save("public/upload/estate/{$estate->no}_1.jpg");


            for ($i = 1; $i<=15; $i++) {
                $this->load->library('SimpleImage');

                if (file_exists("buyuk/{$estate->no}_$i.jpg")) {

                    $image = $this->simpleimage->load("buyuk/{$estate->no}_$i.jpg");

                    $image->resize(600, 450);
                    $image->save("public/upload/estate/normal/{$estate->no}_$i.jpg");
                    $image->save("public/upload/estate/large/{$estate->no}_$i.jpg");

                    $image->resize(200, 150);
                    $image->save("public/upload/estate/thumb/{$estate->no}_$i.jpg");


                    $this->db->insert('estate_images', array(
                        'estateId' => $insertId,
                        'image' => "{$estate->no}_$i.jpg"
                    ));
                }
            }




            $estates[] = $estate;


        }

        echo count($estates);
        echo '<pre>';
        print_r($estates);

        */

    }



} 