<?php


class ContactController  extends CI_Controller
{
    public $module = 'contact';

    public function index()
    {
        $this->load->model('contact');
        $this->load->helper('form');

        if ($this->input->post()) {

            $this->load->library('form_validation');
            $this->form_validation->set_rules('fullname', 'Lütfen Adınızı ve Soyadınızı yazınız.', 'required');
            $this->form_validation->set_rules('phone', 'Lütfen Telefon numaranızı adresinizi yazınız.', 'required');
            $this->form_validation->set_rules('email', 'Lütfen E-Posta adresinizi yazınız.', 'required|valid_email');
            $this->form_validation->set_rules('comment', 'Yorumunuz çok kısa.', 'required|min_length[5]');

            if ($this->form_validation->run() == true) {
                $success = $this->contact->insert();

                if ($success) {
                    $this->site->setAlert('success', 'Mesajınız iletildi.');
                    redirect(current_url().'#form');
                }
            } else {
                $this->site->setAlert('error', $this->form_validation->error_string('<div>&bull; ', '</div>'));
            }
        }



        $this->load->view('layout/master', array(
            'view' => 'contact/index',
            'data' => array()
        ));

    }



} 