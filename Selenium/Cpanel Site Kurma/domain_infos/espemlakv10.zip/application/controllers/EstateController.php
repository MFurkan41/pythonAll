<?php


class EstateController  extends CI_Controller
{

    public $module = 'estate';



    public function status($status)
    {
        $this->load->model('estate');

        $statusList = array(
            'rent' => array('status' => 'Kiralık', 'pageTitle' => 'Tüm Kiralık İlanlar'),
            'sale' => array('status' => 'Satılık', 'pageTitle' => 'Tüm Satılık İlanlar')
        );

        $estates = array();
        $pagination = null;
        $estateCount = $this->estate->count($statusList[$status]['status']);

        if ($estateCount > 0) {
            $config = array(
                'base_url' => clink(array("@$status")),
                'total_rows' => $estateCount,
                'per_page' => 15
            );

            $this->load->library('pagination');
            $this->pagination->initialize($config);

            $estates = $this->estate->all($statusList[$status]['status'], $this->pagination->per_page, $this->pagination->offset);
            $pagination = $this->pagination->create_links();
        }

        $this->site->set('metaTitle', $statusList[$status]['pageTitle'], ' - ');

        $this->load->view('layout/master', array(
            'view' => 'estate/list',
            'data' => array(
                'pageTitle' => $statusList[$status]['pageTitle'],
                'estates' => $estates,
                'pagination' => $pagination,
            )
        ));


    }



    public function detail($id)
    {
        $this->load->model('estate');

        if (! $estate = $this->estate->findId($id)) {
            show_404();
        }

        $estate->title2 = $estate->estateStatus .' '. $estate->typeTitle .' / '. $estate->districtTitle .', '. $estate->townTitle .' - '. $estate->cityTitle;

        if ($this->input->post()) {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('fullname', 'Lütfen Adınızı ve Soyadınızı yazınız.', 'required');
            $this->form_validation->set_rules('phone', 'Lütfen Telefon Numaranızı yazınız', 'required');
            $this->form_validation->set_rules('message', 'Lütfen Mesajınızı yazınız', 'required|min_length[5]');

            if ($this->form_validation->run() == true) {
                $success = $this->estate->newContactRequest($estate);

                if (isset($this->maillist)) {
                    $this->maillist->insert();
                }

                if ($success) {
                    $this->site->setAlert('success', 'Mesajınız iletildi.');
                    redirect(current_url().'#contact');
                }
            } else {
                $this->site->setAlert('danger', $this->form_validation->error_string('<div>&bull; ', '</div>'));
            }
        }




        $this->estate->images($estate);
        $this->estate->properties($estate);
        $this->estate->increaseView($estate);



        $this->site->set('metaTitle', !empty($estate->metaTitle) ? $estate->metaTitle : $estate->title.' '.$estate->title2, ' - ');

        if (! empty($estate->metaDescription)) {
            $this->site->set('metaDescription', $estate->metaDescription);
        }

        $this->site->set('metaKeywords', $estate->metaKeywords);

        $this->site->set('ogType', 'article');
        $this->site->set('ogTitle', $estate->title.' '.$estate->title2);
        $this->site->set('ogDescription', ! empty($estate->metaDescription) ? $estate->metaDescription : strip_tags($estate->description));

        if (! empty($estate->image)) {
            $this->site->set('ogImage', uploadPath($estate->image, 'estate'));
        }


        $this->load->view('layout/master', array(
            'view' => 'estate/detail',
            'data' => array('estate' => $estate)
        ));

    }





    public function search()
    {
        $this->load->model('estate');

        $estates = array();
        $pagination = null;

        /**
         * Emlak no'ya göre arama yapıldıysa kontrolü yapılır.
         * Sonuç olmaması durumunda normal view yüklenir.
         */
        if ($this->input->get('searchNo')) {
            if ($estate = $this->estate->checkNo($this->input->get('searchNo'))) {
                redirect(clink(array('@estate', $estate->id)));
            }
        } else {
            $estateCount = $this->estate->filterCount();

            if ($estateCount > 0) {
                $config = array(
                    'base_url' => clink(array('@search')),
                    'total_rows' => $estateCount,
                    'per_page' => 15
                );

                $this->load->library('pagination');
                $this->pagination->initialize($config);

                $estates = $this->estate->filter($this->pagination->per_page, $this->pagination->offset);
                $pagination = $this->pagination->create_links();
            }
        }


        $this->site->set('metaTitle', 'Arama Sonuçları', ' - ');



        $this->load->view('layout/master', array(
            'view' => 'estate/search',
            'data' => array(
                'estates' => $estates,
                'pagination' => $pagination,
            )
        ));
    }


    public function insert()
    {
        $this->load->model('estate');
        $this->load->helper('form');

        if ($this->input->post()) {

        $this->load->library('form_validation');
        $this->form_validation->set_rules('insertStatus', 'Lütfen Emlak Durumunu seçiniz.', 'required');
        $this->form_validation->set_rules('insertCity', 'Lütfen Şehir seçiniz.', 'required');
        $this->form_validation->set_rules('insertTown', 'Lütfen İlçe seçiniz.', 'required');
        $this->form_validation->set_rules('insertDistrict', 'Lütfen Semt seçiniz.', 'required');
        $this->form_validation->set_rules('insertKind', 'Lütfen Emlak Türü seçiniz.', 'required');
        $this->form_validation->set_rules('insertType', 'Lütfen Emlak Tipi seçiniz.', 'required');
        $this->form_validation->set_rules('insertPrice', 'Lütfen Fiyat yazınız.', 'required');
        $this->form_validation->set_rules('insertDescription', 'Lütfen Açıklama yazınız.', 'required');
        $this->form_validation->set_rules('insertFullname', 'Lütfen Adınızı Soyadınızı yazınız.', 'required');
        $this->form_validation->set_rules('insertPhone', 'Lütfen Telefon numaranızı adresinizi yazınız.', 'required');
        $this->form_validation->set_rules('insertEmail', 'Lütfen E-Posta adresinizi yazınız.', 'required|valid_email');

        if ($this->form_validation->run() == false) {
            $this->site->setAlert('danger', $this->form_validation->error_string('<div>&bull; ', '</div>'));
        }


        if (! $this->site->isAlert()) {
            $config = array(
                'upload_path' => 'public/upload/estate/insert/',
                'allowed_types' => 'gif|jpg|png',
                'encrypt_name' => true
            );
            $this->load->library('upload', $config);

            if (! $this->upload->do_upload('insertImage')) {
                $this->site->setAlert('danger', $this->upload->display_errors('<div>&bull; ', '</div>'));
            }
        }


        if (! $this->site->isAlert()) {
            $data = $this->upload->data();
            $imageData =  array(
                'name' => $data['file_name'],
                'path' => $data['full_path'],
                'ext' => $data['file_ext'],
                'width' => $data['image_width'],
                'height' => $data['image_height']
            );

            if ($imageData['width'] < 600 || $imageData['height'] < 450) {
                $this->site->setAlert('danger', '<div>&bull; Resim boyutları en az 600x450px olmalı.</div>');
            }
        }


        if (! $this->site->isAlert()) {
            $success = $this->estate->insert($imageData);

            if ($success) {
                $this->site->setAlert('success', 'Emlak ilanınız başarıyla kaldedildi.');
                redirect(current_url());
            }
        }
    }



        $this->load->view('layout/master', array(
            'view' => 'estate/insert',
            'data' => array(
            )
        ));

    }


} 