<?php

use Sirius\Admin\Manager;

class ShowcaseAdminController extends Manager
{
    public $moduleTitle = 'Vitrindekiler';
    public $module = 'showcase';
    public $table = 'showcases';
    public $model = 'showcase';



    // Filtreleme yapılacak querystring/kolonlar.
    // public $filter = array('type');

    public $actions = array(
        'records' => 'list',
        'order' => 'list',
        'relations' => 'insert',
        'insert' => 'insert',
        'delete' => 'delete',
    );



    public function relations()
    {
        $json = array('success' => true, 'html' => 'Kayıt bulunamadı.');

        $json['html'] = $this->load->view(clink(array($this->module, 'relations')), array(
            'records' => $this->appmodel->relations()
        ), true);

        echo json_encode($json);
    }


    public function insert()
    {
        $json = array('success' => true, 'html' => 'Kayıt bulunamadı.');
        $success = $this->appmodel->insert((int) $this->uri->segment(3));

        if ($success){
            $json['success'] = true;
        }

        echo json_encode($json);

    }
} 