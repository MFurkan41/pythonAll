<?php

use Sirius\Admin\Manager;

class EstatecontactAdminController extends Manager
{
    public $moduleTitle = 'Bilgi Talepleri';
    public $module = 'estatecontact';
    public $table = 'estate_contacts';
    public $model = 'estatecontact';

    // Arama yapılacak kolonlar.
    public $search = array('fullname');


    // Filtreleme yapılacak querystring/kolonlar.
     public $filter = array('viewed');

    public $actions = array(
        'records' => 'list',
        'view' => 'view',
        'delete' => 'delete',
    );


    public function view()
    {
        if (! $record = $this->appmodel->id($this->uri->segment(3))) {
            show_404();
        }

        $this->appmodel->viewed($record);

        $this->breadcrumb('Detaylar');

        $this->viewData['record'] = $record;

        $this->render('view');

    }





} 