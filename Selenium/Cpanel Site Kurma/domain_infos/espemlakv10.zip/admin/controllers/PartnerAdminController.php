<?php

use Sirius\Admin\Manager;

class PartnerAdminController extends Manager
{
    public $moduleTitle = 'Ortaklar';
    public $module = 'partner';
    public $table = 'partners';
    public $model = 'partner';

    // Arama yapılacak kolonlar.
    public $search = array('title');


    // Filtreleme yapılacak querystring/kolonlar.
    // public $filter = array('type');

    public $actions = array(
        'records' => 'list',
        'order' => 'list',
        'insert' => 'insert',
        'update' => 'update',
        'delete' => 'delete',

    );
	
	
	protected function insertValidateRules()
    {
        $this->form_validation->set_rules('link', 'Lütfen Bağlantı yazınız.', 'required');
    }

	
	protected function updateValidateRules()
    {
		$this->form_validation->set_rules('link', 'Lütfen Bağlantı yazınız.', 'required');
    }


    protected function insertAfterValidate()
    {
        $this->utils
            ->uploadInput('imageFile')
            ->minSizes(1, 1)
            ->addProcessSize('normal', 360, 360, 'partner', 'fit');


        if ($this->input->post('imageUrl')) {
            $this->modelData['image'] = $this->utils->imageDownload(true, $this->input->post('imageUrl'));
        } else {
            $this->modelData['image'] = $this->utils->imageUpload(true);
        }
    }

    protected function updateAfterValidate($record)
    {
        $this->utils
            ->uploadInput('imageFile')
            ->minSizes(1, 1)
            ->addProcessSize('normal', 360, 360, 'partner', 'fit');


        if ($this->input->post('imageUrl')) {
            $this->modelData['image'] = $this->utils->imageDownload(false, $this->input->post('imageUrl'), $record->image);
        } else {
            $this->modelData['image'] = $this->utils->imageUpload(false, $record->image);
        }
    }


} 