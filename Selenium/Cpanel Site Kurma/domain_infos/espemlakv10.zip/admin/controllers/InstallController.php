<?php

use Sirius\Admin\Installer as InstallManager;


class InstallController extends InstallManager
{

} 