-- ----------------------------
-- Table structure for `contacts`
-- ----------------------------
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fullname` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(255) NOT NULL,
  `viewed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ----------------------------
-- Records of contacts
-- ----------------------------
INSERT INTO `module_arguments` VALUES (null, 'contact', 'title', 'Başlık', null, 'text', '{\"required\":true}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'metaTitle', 'Meta Başlık', null, 'textarea', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'metaDescription', 'Meta Tanım', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'metaKeywords', 'Meta Anahtar Kelimeler', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'googleMap', 'Google Map Kordinatları', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'detail', 'İletişim Bilgileri', null, 'editor', '{\"required\":true}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'googleMapText', 'Google Map Yazısı', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'smtpHost', 'Smtp Sunucusu', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'smtpPort', 'Smtp Port', '587', 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'smtpUser', 'Smtp Kullanıcı Adı', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'smtpPass', 'Smtp Parola', null, 'text', '{}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'notification', 'Bildirim Gönderimi', '0', 'dropdown', '{\"required\":true, \"options\":{\"0\": \"Bildirim Gönderme\", \"1\": \"Bildirim Gönder\"}}', 'tr');
INSERT INTO `module_arguments` VALUES (null, 'contact', 'notificationMail', 'Bildirim Maili', null, 'text', '{}', 'tr');