<?php

class Installer
{

}