<?php
error_reporting(0);
?>
<div class="row">
    <div class="col-md-12">

        <div class="row">
            <?php foreach ($widgets as $widget): ?>
                <div class="col-lg-2">
                    <a class="<?php echo isset($widget->type) ? $widget->type : 'app' ?> <?php echo isset($widget->class) ? $widget->class : 'app-info' ?> clearfix" href="<?php echo $widget->url ?>">
                        <div class="app-icon"><i class="fa <?php echo $widget->icon ?>"></i></div>
                        <div class="app-body">
                            <?php if ($widget->count > 0): ?>
                                <span class="label label-danger"><?php echo $widget->count .' '. $widget->info ?></span>
                            <?php endif; ?>
                            <div class="app-title">
                                <?php echo $widget->title ?>
                                <span><?php echo $widget->total ?> Kayıt</span>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>



        <?php
        $mostViewedKiralik = $this->db
            ->select("estates.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, '<br>', districts.title, ', ', towns.title, ' - ', cities.title) title", false)
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', 'Kiralık')
            ->order_by('estates.views', 'desc')
            ->order_by('estates.id', 'desc')
            ->get()
            ->row();

        $mostViewedSatilik = $this->db
            ->select("estates.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, '<br>', districts.title, ', ', towns.title, ' - ', cities.title) title", false)
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', 'Satılık')
            ->order_by('estates.views', 'desc')
            ->order_by('estates.id', 'desc')
            ->get()
            ->row();

        $leastViewedKiralik = $this->db
            ->select("estates.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, '<br>', districts.title, ', ', towns.title, ' - ', cities.title) title", false)
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', 'Kiralık')
            ->order_by('estates.views', 'asc')
            ->order_by('estates.id', 'desc')
            ->get()
            ->row();


        $leastViewedSatilik = $this->db
            ->select("estates.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, '<br>', districts.title, ', ', towns.title, ' - ', cities.title) title", false)
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->where('estates.estateStatus', 'Satılık')
            ->order_by('estates.views', 'asc')
            ->order_by('estates.id', 'desc')
            ->get()
            ->row();
        ?>

        <div class="row">

            <div class="col-lg-3">
                <a class="app app-success clearfix" href="<?php echo clink(array('estate', 'update', $mostViewedKiralik->id)) ?>">
                    <div class="app-icon" style="width: 30%"><i class="fa fa-building"></i></div>
                    <div class="app-body" style="width: 70%">
                        <span class="label label-danger">En Çok Gösterilen Kiralık Emlak</span>
                        <div class="app-title">
                            <?php echo $mostViewedKiralik->title ?>
                            <span><?php echo $mostViewedKiralik->views ?> Gösterim</span>
                        </div>
                    </div>
                </a>
            </div>


            <div class="col-lg-3">
                <a class="app app-success clearfix" href="<?php echo clink(array('estate', 'update', $mostViewedSatilik->id)) ?>">
                    <div class="app-icon" style="width: 30%"><i class="fa fa-building"></i></div>
                    <div class="app-body" style="width: 70%">
                        <span class="label label-danger">En Çok Gösterilen Satılık Emlak</span>
                        <div class="app-title">
                            <?php echo $mostViewedSatilik->title ?>
                            <span><?php echo $mostViewedSatilik->views ?> Gösterim</span>
                        </div>
                    </div>
                </a>
            </div>


            <div class="col-lg-3">
                <a class="app app-success clearfix" href="<?php echo clink(array('estate', 'update', $leastViewedKiralik->id)) ?>">
                    <div class="app-icon" style="width: 30%"><i class="fa fa-building"></i></div>
                    <div class="app-body" style="width: 70%">
                        <span class="label label-danger">En Az Gösterilen Kiralık Emlak</span>
                        <div class="app-title">
                            <?php echo $leastViewedKiralik->title ?>
                            <span><?php echo $leastViewedKiralik->views ?> Gösterim</span>
                        </div>
                    </div>
                </a>
            </div>


            <div class="col-lg-3">
                <a class="app app-success clearfix" href="<?php echo clink(array('estate', 'update', $leastViewedSatilik->id)) ?>">
                    <div class="app-icon" style="width: 30%"><i class="fa fa-building"></i></div>
                    <div class="app-body" style="width: 70%">
                        <span class="label label-danger">En Az Gösterilen Satılık Emlak</span>
                        <div class="app-title">
                            <?php echo $leastViewedSatilik->title ?>
                            <span><?php echo $leastViewedSatilik->views ?> Gösterim</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>

    </div>

    <?php if (! empty($analytics)): ?>
        <div class="col-md-6">

                <div class="panel panel-default">
                    <div class="panel-heading">Ziyaretçi İstatistikleri</div>
                    <div class="panel-body">
                        <?php if (is_array($analytics)) :?>
                            <div id="analytics"></div>

                            <script type="text/javascript">
                                Morris.Area({
                                    element: 'analytics',
                                    data: [
                                        <?php foreach ($analytics as $key => $val): ?>
                                        {x: '<?php echo $this->date->set($key)->dateWithName() ?>', visitors: '<?php echo $val['visitors'] ?>',visits: '<?php echo $val['visits'] ?>'},
                                        <?php endforeach; ?>
                                    ],
                                    xkey: 'x',
                                    ykeys: ['visitors', 'visits'],
                                    labels: ['Tekil', 'Çoğul'],
                                    lineColors: ['#4da944', '#42c1f7'],
                                    parseTime: false,
                                    fillOpacity: 0.2
                                });
                            </script>
                        <?php endif; ?>
                    </div>
                </div>

        </div>
    <?php endif; ?>
</div>

