<div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-link"></i> İlişkili Kayıtlar</div>
    <table class="table table-bordered table-hover">
        <thead>
        <tr>
            <th>Başlık</th>
            <th width="37"></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($records as $item): ?>
            <tr>
                <td><?php echo $item->relationTitle ?></td>
                <td class="text-right">
                    <a class="btn btn-xs btn-danger relation-insert" href="<?php echo $this->module ?>/insert/<?php echo $item->id ?>">
                        <i class="fa fa-plus"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>

        <?php if (count($records) == 0): ?>
            <tr>
                <td colspan="50">Kayıt bulunamadı.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>