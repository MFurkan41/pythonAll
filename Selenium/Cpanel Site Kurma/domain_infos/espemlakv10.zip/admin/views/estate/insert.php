<?php
error_reporting(0);
?>
<div class="row">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="col-md-8">
            <?php echo $this->utils->alert(); ?>

            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-plus-square"></i> Yeni Kayıt Ekle</div>
                <div class="panel-body">

                    <?php echo bsFormText('title', 'Başlık') ?>
                    <?php echo bsFormText('no', 'No', array('required' => true)) ?>
                    <?php echo bsFormDropdown('city', 'Şehir', array(
                        'required' => true,
                        'options' => prepareForSelect($this->appmodel->getCities(), 'id', 'title', 'Seçiniz'),
                        'class' => 'city-list'
                    )) ?>
                    <?php echo bsFormDropdown('town', 'İlçe', array(
                        'required' => true,
                        'options' => prepareForSelect($this->appmodel->getTowns($this->input->post('city')), 'id', 'title', 'Şehir Seçiniz'),
                        'class' => 'town-list'
                    )) ?>

                    <?php echo bsFormDropdown('district', 'Semt', array(
                        'required' => true,
                        'options' => prepareForSelect($this->appmodel->getDistricts($this->input->post('town')), 'id', 'title', 'İlçe Seçiniz'),
                        'class' => 'district-list'
                    )) ?>

                    <?php echo bsFormDropdown('status', 'Emlak Durumu', array(
                        'required' => true,
                        'options' => array('' => 'Seçiniz', 'Kiralık' => 'Kiralık', 'Satılık' => 'Satılık'),
                    )) ?>

                    <?php echo bsFormDropdown('kind', 'Emlak Türü', array(
                        'required' => true,
                        'options' => prepareForSelect($this->appmodel->getKinds(), 'id', 'title', 'Seçiniz'),
                        'class' => 'kind-list'
                    )) ?>

                    <?php echo bsFormDropdown('type', 'Emlak Tipi', array(
                        'required' => true,
                        'options' => prepareForSelect($this->appmodel->getTypes($this->input->post('kind')), 'id', 'title', 'Emlak Türü Seçiniz'),
                        'class' => 'type-list'
                    )) ?>

                    <?php echo bsFormText('price', 'Fiyat', array('required' => true)) ?>

                    <?php echo bsFormImage('image', 'Resim') ?>
                    <?php echo bsFormEditor('description', 'Açıklama') ?>
                    <?php echo bsFormDropdown('room', 'Oda Sayısı', array(
                        'options' => prepareForSelect($this->appmodel->getRooms(), 'id', 'title', 'Seçiniz'),
                    )) ?>
                    <?php echo bsFormText('bath', 'Banyo Sayısı') ?>
                    <?php echo bsFormText('squaremeter', 'Metrekare (m2)') ?>
                    <?php echo bsFormDropdown('floor', 'Bulunduğu Kat', array(
                        'options' => prepareForSelect($this->appmodel->getFloors(), 'id', 'title', 'Seçiniz'),
                    )) ?>
                    <?php echo bsFormText('storeyCount', 'Binadaki Kat Sayısı') ?>

                    <?php echo bsFormDropdown('buildingAge', 'Binanın Yaşı', array(
                        'options' => prepareForSelect($this->appmodel->getBuildingAges(), 'id', 'title', 'Seçiniz'),
                    )) ?>

                    <?php echo bsFormDropdown('heating', 'Isınma Şekli', array(
                        'options' => prepareForSelect($this->appmodel->getHeatings(), 'id', 'title', 'Seçiniz'),
                    )) ?>

                    <?php echo bsFormDropdown('usageStatus', 'Kullanım Durumu', array(
                        'options' => prepareForSelect($this->appmodel->getUsageStatuses(), 'id', 'title', 'Seçiniz'),
                    )) ?>
                    <?php echo bsFormText('mapCoordinate', 'Google Map Kordinatlatı') ?>
                    <?php echo bsFormText('video', 'Youtube Video ID') ?>

                </div>
                <div class="panel-footer">
                    <button class="btn btn-success" type="submit">Kaydet</button>
                    <button class="btn btn-success" type="submit" name="redirect" value="<?php echo $this->module ?>/images/@id">Kaydet ve Resim Yükle</button>
                    <button class="btn btn-success" type="submit" name="redirect" value="<?php echo $this->module ?>/records">Kaydet ve Listeye Dön</button>
                    <a class="btn btn-default" href="<?php echo $this->module ?>/records">Vazgeç</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-plus-square"></i> Meta Bilgileri</div>

                <div class="panel-body">

                    <div class="form-group">
                        <label>Emlak Özellikleri</label>
                        <?php echo form_multiselect('properties[]', prepareForSelect($this->appmodel->getProperties(), 'id', 'title'), set_value('properties[]'), 'class="form-control" id="properties" size="10"'); ?>
                        <div class="help-block"><kbd>Ctrl</kbd> tuşuna basılı tutarak birden fazla kategori seçebilirsiniz.</div>
                    </div>


                    <?php echo bsFormText('metaTitle', 'Title') ?>
                    <?php echo bsFormTextarea('metaDescription', 'Description') ?>
                    <?php echo bsFormTextarea('metaKeywords', 'Keywords') ?>
                </div>
            </div>
        </div>
    </form>
</div>