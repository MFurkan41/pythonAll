
<div class="row">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="col-md-8">
            <?php echo $this->utils->alert(); ?>

            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-edit"></i> Kayıt Düzenle</div>
                <div class="panel-body">


                    <?php echo bsFormText('title', 'Başlık', array('value' => $record->title)) ?>
                    <?php echo bsFormText('no', 'No', array('required' => true, 'value' => $record->no)) ?>
                    <?php echo bsFormDropdown('city', 'Şehir', array(
                        'required' => true,
                        'value' => $record->cityId,
                        'options' => prepareForSelect($this->appmodel->getCities(), 'id', 'title', 'Seçiniz'),
                        'class' => 'city-list'
                    )) ?>
                    <?php echo bsFormDropdown('town', 'İlçe', array(
                        'required' => true,
                        'value' => $record->townId,
                        'options' => prepareForSelect($this->appmodel->getTowns($record->cityId), 'id', 'title', 'Şehir Seçiniz'),
                        'class' => 'town-list'
                    )) ?>

                    <?php echo bsFormDropdown('district', 'Semt', array(
                        'required' => true,
                        'value' => $record->districtId,
                        'options' => prepareForSelect($this->appmodel->getDistricts($record->townId), 'id', 'title', 'İlçe Seçiniz'),
                        'class' => 'district-list'
                    )) ?>

                    <?php echo bsFormDropdown('status', 'Emlak Durumu', array(
                        'required' => true,
                        'value' => $record->estateStatus,
                        'options' => array('' => 'Seçiniz', 'Kiralık' => 'Kiralık', 'Satılık' => 'Satılık'),
                    )) ?>

                    <?php echo bsFormDropdown('kind', 'Emlak Türü', array(
                        'required' => true,
                        'value' => $record->kindId,
                        'options' => prepareForSelect($this->appmodel->getKinds(), 'id', 'title', 'Seçiniz'),
                        'class' => 'kind-list'
                    )) ?>

                    <?php echo bsFormDropdown('type', 'Emlak Tipi', array(
                        'required' => true,
                        'value' => $record->typeId,
                        'options' => prepareForSelect($this->appmodel->getTypes($record->kindId), 'id', 'title', 'Emlak Türü Seçiniz'),
                        'class' => 'type-list'
                    )) ?>

                    <?php echo bsFormText('price', 'Fiyat', array('required' => true, 'value' => $record->price)) ?>

                    <?php echo bsFormImage('image', 'Resim', array('value' => $record->image, 'path' => '../public/upload/estate/')) ?>
                    <?php echo bsFormEditor('description', 'Açıklama', array('value' => $record->description)) ?>



                    <?php echo bsFormDropdown('room', 'Oda Sayısı', array(
                        'options' => prepareForSelect($this->appmodel->getRooms(), 'id', 'title', 'Seçiniz'),
                        'value' => $record->roomId
                    )) ?>
                    <?php echo bsFormText('bath', 'Banyo Sayısı', array('value' => $record->bath)) ?>
                    <?php echo bsFormText('squaremeter', 'Metrekare (m2)', array('value' => $record->squaremeter)) ?>
                    <?php echo bsFormDropdown('floor', 'Bulunduğu Kat', array(
                        'options' => prepareForSelect($this->appmodel->getFloors(), 'id', 'title', 'Seçiniz'),
                        'value' => $record->floorId
                    )) ?>
                    <?php echo bsFormText('storeyCount', 'Binadaki Kat Sayısı') ?>

                    <?php echo bsFormDropdown('buildingAge', 'Binanın Yaşı', array(
                        'options' => prepareForSelect($this->appmodel->getBuildingAges(), 'id', 'title', 'Seçiniz'),
                        'value' => $record->buildingAgeId
                    )) ?>

                    <?php echo bsFormDropdown('heating', 'Isınma Şekli', array(
                        'options' => prepareForSelect($this->appmodel->getHeatings(), 'id', 'title', 'Seçiniz'),
                        'value' => $record->heatingId,
                    )) ?>

                    <?php echo bsFormDropdown('usageStatus', 'Kullanım Durumu', array(
                        'options' => prepareForSelect($this->appmodel->getUsageStatuses(), 'id', 'title', 'Seçiniz'),
                        'value' => $record->usageStatusId,
                    )) ?>

                    <?php echo bsFormText('mapCoordinate', 'Google Map Kordinatlatı', array('value' => $record->mapCoordinate)) ?>

                    <?php echo bsFormText('video', 'Youtube Video ID', array('value' => $record->video)) ?>


                </div>
                <div class="panel-footer">
                    <button class="btn btn-success" type="submit">Kaydet</button>
                    <a class="btn btn-default" href="<?php echo $this->module ?>/records">Vazgeç</a>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-plus-square"></i> Meta Bilgileri</div>

                <div class="panel-body">

                    <div class="form-group">
                        <label>Güncelle</label>
                        <div class="checkbox">
                            <label><input type="checkbox" name="update" value="true"> İlanı güncellendi olarak işaretle</label>
                        </div>
                    </div>



                    <div class="form-group">
                        <label>Emlak Özellikleri</label>
                        <?php echo form_multiselect('properties[]', prepareForSelect($this->appmodel->getProperties(), 'id', 'title'), set_value('properties[]', $this->appmodel->getPropertyRelations($record)), 'class="form-control" id="properties" size="10"'); ?>
                        <div class="help-block"><kbd>Ctrl</kbd> tuşuna basılı tutarak birden fazla kategori seçebilirsiniz.</div>
                    </div>


                    <?php echo bsFormText('metaTitle', 'Title', array('value' => $record->metaTitle)) ?>
                    <?php echo bsFormTextarea('metaDescription', 'Description', array('value' => $record->metaDescription)) ?>
                    <?php echo bsFormTextarea('metaKeywords', 'Keywords', array('value' => $record->metaKeywords)) ?>
                </div>
            </div>
        </div>
    </form>
</div>

