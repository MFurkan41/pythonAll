
<?php echo $this->utils->alert(); ?>

<div class="panel panel-default">
    <div class="panel-heading"><i class="fa fa-table"></i> <?php echo $this->moduleTitle ?></div>
    <div class="panel-toolbar clearfix">
        <div class="row">
            <div class="col-md-4">
                <?php if ($this->permission('delete')): ?>
                    <a class="btn btn-sm btn-info checkall" data-toggle="button"><i class="fa fa-check-square-o"></i> Hepsini Seç</a>
                    <a class="btn btn-sm btn-danger deleteall" href="<?php echo $this->module ?>/delete"><i class="fa fa-trash-o"></i></a>
                <?php endif; ?>
                <?php if ($this->permission('insert')): ?>
                    <a class="btn btn-sm btn-success" href="<?php echo $this->module ?>/insert"><i class="fa fa-plus"></i> Yeni Kayıt</a>
                <?php endif; ?>

            </div>
            <div class="col-md-8 text-right">
                <form class="form-inline" action="" method="get" id="filter" accept-charset="utf-8" style="display: inline-block;">
                    <?php echo bsFormDropdown('estateStatus', 'Emlak Durumu : ', array(
                        'value' => $this->input->get('estateStatus'),
                        'options' => array('' => 'Hepsi', 'Kiralık' => 'Kiralık', 'Satılık' => 'Satılık'),
                        'class' => 'input-sm'
                    )); ?>

                    <?php $this->view('filter') ?>
                </form>
            </div>
        </div>
    </div>
    <?php

    $sortType = $this->input->get('sortType') == 'desc' ? 'desc':'asc';
    $sortBy = $this->input->get('sortBy') ? $this->input->get('sortBy') : 'id';

    if (! $this->input->get('sortBy')) {
        $sortType = 'desc';
    }
    $sortTypeOptions = array(
        'desc' => array('reverse' => 'asc', 'icon' => 'up'),
        'asc' => array('reverse' => 'desc', 'icon' => 'down')
    );
    ?>
    <table class="table table-bordered table-hover">
        <thead>
        <tr>
            <th width="40" class="text-center"><i class="fa fa-ellipsis-v"></i></th>
            <th width="50">
                #
                <?php if ($sortBy == 'id'): ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'id', 'sortType' => $sortTypeOptions[$sortType]['reverse']), true) ?>"><i class="fa fa-chevron-<?php echo $sortTypeOptions[$sortType]['icon'] ?> text-primary"></i></a>
                <?php else: ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'id', 'sortType' => 'asc'), true) ?>"><i class="fa fa-chevron-down text-muted"></i></a>
                <?php endif; ?>
            </th>
            <th>
                Emlak No
                <?php if ($sortBy == 'no'): ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'no', 'sortType' => $sortTypeOptions[$sortType]['reverse']), true) ?>"><i class="fa fa-chevron-<?php echo $sortTypeOptions[$sortType]['icon'] ?> text-primary"></i></a>
                <?php else: ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'no', 'sortType' => 'asc'), true) ?>"><i class="fa fa-chevron-down text-muted"></i></a>
                <?php endif; ?>
            </th>
            <th>Emlak Durumu</th>
            <th>Konum</th>
            <th>Emlak</th>
            <th>
                Fiyat
                <?php if ($sortBy == 'price'): ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'price', 'sortType' => $sortTypeOptions[$sortType]['reverse']), true) ?>"><i class="fa fa-chevron-<?php echo $sortTypeOptions[$sortType]['icon'] ?> text-primary"></i></a>
                <?php else: ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'price', 'sortType' => 'asc'), true) ?>"><i class="fa fa-chevron-down text-muted"></i></a>
                <?php endif; ?>
            </th>
            <th>
                Güncelleme Tarihi
                <?php if ($sortBy == 'updateDate'): ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'updateDate', 'sortType' => $sortTypeOptions[$sortType]['reverse']), true) ?>"><i class="fa fa-chevron-<?php echo $sortTypeOptions[$sortType]['icon'] ?> text-primary"></i></a>
                <?php else: ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'updateDate', 'sortType' => 'asc'), true) ?>"><i class="fa fa-chevron-down text-muted"></i></a>
                <?php endif; ?>
            </th>
            <th class="text-center">
                Gösterim
                <?php if ($sortBy == 'views'): ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'views', 'sortType' => $sortTypeOptions[$sortType]['reverse']), true) ?>"><i class="fa fa-chevron-<?php echo $sortTypeOptions[$sortType]['icon'] ?> text-primary"></i></a>
                <?php else: ?>
                    <a href="<?php echo clink(array($this->module, 'records'), array('sortBy' => 'views', 'sortType' => 'asc'), true) ?>"><i class="fa fa-chevron-down text-muted"></i></a>
                <?php endif; ?>
            </th>
            <th width="100" class="text-center">Resimler</th>
            <th width="100" class="text-center">Özellikler</th>
            <th width="100" class="text-right">İşlem</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($records as $item): ?>
        <tr>
            <td class="text-center"><input type="checkbox" class="checkall-item" value="<?php echo $item->id ?>" /></td>
            <td><?php echo $item->id ?></td>
            <td><?php echo $item->no ?></td>
            <td><?php echo $item->estateStatus ?></td>
            <td><?php echo $item->districtTitle ?>, <?php echo $item->townTitle ?> / <?php echo $item->cityTitle ?></td>
            <td><?php echo $item->kindTitle ?> - <?php echo $item->typeTitle ?></td>
            <td><?php echo money($item->price) ?> TL</td>
            <td><?php echo $this->date->set($item->updateDate)->datetimeWithName() ?></td>
            <td class="text-center"><?php echo $item->views ?></td>
            <td class="text-center">
                <a class="btn btn-success btn-xs" href="<?php echo $this->module ?>/images/<?php echo $item->id ?>"><i class="fa fa-picture-o"></i> <?php echo $item->images ?></a>
            </td>
            <td class="text-center">
                <span class="btn btn-success btn-xs"><i class="fa fa-file-text-o"></i> <?php echo $item->properties ?></span>
            </td>
            <td class="text-right">
                <a class="btn btn-xs btn-warning" href="../<?php echo clink(array('@estate', $item->id)) ?>" target="_blank"><i class="fa fa-external-link-square "></i></a>
                <?php if ($this->permission('update')): ?>
                <a class="btn btn-xs btn-primary" href="<?php echo $this->module ?>/update/<?php echo $item->id ?>"><i class="fa fa-edit"></i></a>
                <?php endif; ?>
                <?php if ($this->permission('delete')): ?>
                <a class="btn btn-xs btn-danger confirm-delete" href="<?php echo $this->module ?>/delete/<?php echo $item->id ?>"><i class="fa fa-trash-o"></i></a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (! empty($pagination)): ?>
        <div class="panel-footer">
            <?php echo $pagination ?>
        </div>
    <?php endif; ?>
</div>