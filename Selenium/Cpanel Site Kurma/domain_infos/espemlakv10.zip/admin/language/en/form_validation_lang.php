<?php

$lang['required']			= "%s";
$lang['isset']				= "%s";
$lang['valid_email']		= "%s";
$lang['valid_emails']		= "%s";
$lang['valid_url']			= "%s";
$lang['valid_ip']			= "%s";
$lang['min_length']			= "%s";
$lang['max_length']			= "%s";
$lang['exact_length']		= "%s";
$lang['alpha']				= "%s";
$lang['alpha_numeric']		= "%s";
$lang['alpha_dash']			= "%s";
$lang['numeric']			= "%s";
$lang['is_numeric']			= "%s";
$lang['integer']			= "%s";
$lang['regex_match']		= "%s";
$lang['matches']			= "%s";
$lang['is_unique'] 			= "%s";
$lang['is_natural']			= "%s";
$lang['is_natural_no_zero']	= "%s";
$lang['decimal']			= "%s";
$lang['less_than']			= "%s";
$lang['greater_than']		= "%s";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */