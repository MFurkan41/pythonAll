<?php

class Showcase extends CI_Model
{

    public function id($id)
    {
        return $this->db
            ->from($this->table)
            ->where('id', $id)
            ->where('language', $this->language)
            ->get()
            ->row();
    }



    public function all($limit = null, $offset = null)
    {
        $this->utils->filter();


        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->select("{$this->table}.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, ' / ', districts.title, ', ', towns.title, ' - ', cities.title) title", false)
            ->from($this->table)
            ->join('estates', "estates.id = {$this->table}.estateId")
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where("{$this->table}.language", $this->language)
            ->order_by("{$this->table}.order", 'asc')
            ->order_by("{$this->table}.id", 'asc')
            ->get()
            ->result();
    }



    public function count()
    {
        $this->utils->filter();

        return $this->db
            ->from($this->table)
            ->where('language', $this->language)
            ->count_all_results();
    }





    public function insert($relationId)
    {
        $order = 1;
        $lastOrderRecord = $this->db->from($this->table)->order_by('order', 'desc')->limit(1)->get()->row();

        if ($lastOrderRecord) {
            $order = $lastOrderRecord->order + 1;
        }

        $this->db->insert($this->table, array(
            'estateId' => $relationId,
            'order' => $order,
            'language' => $this->language,
        ));

        return $this->db->insert_id();
    }





    public function delete($data)
    {
        if (is_array($data)) {
            $success = $this->db
                ->where_in('id', $data)
                ->delete($this->table);

            return $success;
        }

        $success = $this->db
            ->where('id', $data->id)
            ->delete($this->table);


        return $success;
    }





    public function order($ids = null)
    {
        if (is_array($ids)) {
            $records = $this->db
                ->from($this->table)
                ->where_in('id', $ids)
                ->where('language', $this->language)
                ->order_by('order', 'asc')
                ->order_by('id', 'desc')
                ->get()
                ->result();

            $firstOrder = 0;
            $affected = 0;

            foreach ($records as $record) {
                if ($firstOrder === 0) {
                    $firstOrder = $record->order;
                }

                $order = array_search($record->id, $ids) + $firstOrder;

                if ($record->order != $order) {
                    $this->db
                        ->where('id', $record->id)
                        ->update($this->table, array('order' => $order));

                    if ($this->db->affected_rows() > 0) {
                        $affected++;
                    }
                }

            }

            return $affected;
        }

    }



    public function relations()
    {
        return $this->db
            ->select("estates.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, ' / ', districts.title, ', ', towns.title, ' - ', cities.title) relationTitle", false)
            ->from('estates')
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where("estates.id NOT IN (SELECT estateId FROM showcases WHERE language = '{$this->language}')")
            ->order_by('estates.id', 'desc')
            ->get()
            ->result();
    }

} 