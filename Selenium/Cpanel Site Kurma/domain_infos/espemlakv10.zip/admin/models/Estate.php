<?php

class Estate extends CI_Model
{

    public function isEmptyNo($no, $record = null)
    {
        if ($record) {
            $this->db->where('id !=', $record->id);
        }

        $count = $this->db
            ->from($this->table)
            ->where('no', $no)
            ->count_all_results();

        if ($count == 0) {
            return true;
        }

        return false;
    }


    public function getCities()
    {
        return $this->db
            ->from('cities')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function getTowns($cityId)
    {
        return $this->db
            ->from('towns')
            ->where('cityId', $cityId)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function getDistricts($townId)
    {
        return $this->db
            ->from('districts')
            ->where('townId', $townId)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getKinds()
    {
        return $this->db
            ->from('kinds')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function getTypes($kindId)
    {
        return $this->db
            ->from('types')
            ->where('kindId', $kindId)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getHeatings()
    {
        return $this->db
            ->from('heatings')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getRooms()
    {
        return $this->db
            ->from('rooms')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getFloors()
    {
        return $this->db
            ->from('floors')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getBuildingAges()
    {
        return $this->db
            ->from('building_ages')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getUsageStatuses()
    {
        return $this->db
            ->from('usage_statuses')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getProperties()
    {
        return $this->db
            ->from('properties')
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }

    public function getPropertyRelations($estate)
    {
        $properties = $this->db
            ->from('properties')
            ->join('estate_properties', 'estate_properties.propertyId = properties.id')
            ->where('estate_properties.estateId', $estate->id)
            ->get()
            ->result();

        $result = array();

        foreach ($properties as $property) {
            $result[] = $property->id;
        }

        return $result;
    }


    public function id($id)
    {
        return $this->db
            ->from($this->table)
            ->where('id', $id)
            ->get()
            ->row();
    }


    public function all($limit = null, $offset = null)
    {
        $this->utils->filter();


        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->select("{$this->table}.*,
                types.title typeTitle, kinds.title kindTitle, districts.title districtTitle, towns.title townTitle, cities.title cityTitle,
                (SELECT COUNT(images.id) FROM estate_images images WHERE images.estateId = {$this->table}.id) images,
                (SELECT COUNT(properties.estateId) FROM estate_properties properties WHERE properties.estateId = {$this->table}.id) properties", false)
            ->from($this->table)
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('kinds', 'kinds.id = estates.kindId')
            ->join('types', 'types.id = estates.typeId')
            ->order_by("{$this->table}.id", 'desc')
            ->get()
            ->result();
    }


    public function count()
    {
        $this->utils->filter();

        return $this->db
            ->from($this->table)
            ->count_all_results();
    }

    public function insert($data = array())
    {
        $posts = $this->input->post();

        $this->db->insert($this->table, array(
            'title' => $this->input->post('title'),
            'no' => $this->input->post('no'),
            'cityId' => $this->input->post('city'),
            'townId' => $this->input->post('town'),
            'districtId' => $this->input->post('district'),
            'estateStatus' => $this->input->post('status'),
            'kindId' => $this->input->post('kind'),
            'typeId' => $this->input->post('type'),
            'price' => $this->input->post('price'),
            'image' => $data['image']['name'],
            'description' => $this->input->post('description'),
            'roomId' => empty($posts['room']) ? null : $posts['room'],
            'bath' => $this->input->post('bath'),
            'squaremeter' => $this->input->post('squaremeter'),
            'floorId' => empty($posts['floor']) ? null : $posts['floor'],
            'storeyCount' => $this->input->post('storeyCount'),
            'buildingAgeId' => empty($posts['buildingAge']) ? null : $posts['buildingAge'],
            'heatingId' => empty($posts['heating']) ? null : $posts['heating'],
            'usageStatusId' => empty($posts['usageStatus']) ? null : $posts['usageStatus'],
            'mapCoordinate' => $this->input->post('mapCoordinate'),
            'video' => $this->input->post('video'),
            'date' => $this->date->set()->mysqlDatetime(),
            'updateDate' => $this->date->set()->mysqlDatetime(),
            'metaTitle' => $this->input->post('metaTitle'),
            'metaDescription' => $this->input->post('metaDescription'),
            'metaKeywords' => $this->input->post('metaKeywords'),
        ));

        $insertId = $this->db->insert_id();


        $this->db
            ->where('estateId', $insertId)
            ->delete('estate_properties');

        if ($properties = $this->input->post('properties')) {
            foreach ($properties as &$property) {
                $property = array(
                    'estateId' => $insertId,
                    'propertyId' => $property
                );
            }

            $this->db->insert_batch('estate_properties', $properties);
        }

        return $insertId;
    }




    public function update($record, $data = array())
    {
        $posts = $this->input->post();

        $data = array(
            'title' => $this->input->post('title'),
            'no' => $this->input->post('no'),
            'cityId' => $this->input->post('city'),
            'townId' => $this->input->post('town'),
            'districtId' => $this->input->post('district'),
            'estateStatus' => $this->input->post('status'),
            'kindId' => $this->input->post('kind'),
            'typeId' => $this->input->post('type'),
            'price' => $this->input->post('price'),
            'image' => $data['image']['name'],
            'description' => $this->input->post('description'),
            'roomId' => empty($posts['room']) ? null : $posts['room'],
            'bath' => $this->input->post('bath'),
            'squaremeter' => $this->input->post('squaremeter'),
            'floorId' => empty($posts['floor']) ? null : $posts['floor'],
            'storeyCount' => $this->input->post('storeyCount'),
            'buildingAgeId' => empty($posts['buildingAge']) ? null : $posts['buildingAge'],
            'heatingId' => empty($posts['heating']) ? null : $posts['heating'],
            'usageStatusId' => empty($posts['usageStatus']) ? null : $posts['usageStatus'],
            'mapCoordinate' => $this->input->post('mapCoordinate'),
            'video' => $this->input->post('video'),
            'metaTitle' => $this->input->post('metaTitle'),
            'metaDescription' => $this->input->post('metaDescription'),
            'metaKeywords' => $this->input->post('metaKeywords'),
        );

        if ($this->input->post('update') === 'true') {
            $data['updateDate'] = $this->date->set()->mysqlDatetime();
        }

        $this->db
            ->where('id', $record->id)
            ->update($this->table, $data);

        $affectedRows = $this->db->affected_rows();

        $this->db
            ->where('estateId', $record->id)
            ->delete('estate_properties');

        if ($properties = $this->input->post('properties')) {
            foreach ($properties as &$property) {
                $property = array(
                    'estateId' => $record->id,
                    'propertyId' => $property
                );
            }

            $this->db->insert_batch('estate_properties', $properties);
        }

        return $affectedRows;
    }


    public function delete($data)
    {
        if (is_array($data)) {
            $records = $this->db
                ->from($this->table)
                ->where_in('id', $data)
                ->get()
                ->result();

            foreach ($records as $record) {
                $images = $this->db
                    ->from('estate_images')
                    ->where('estateId', $record->id)
                    ->get()
                    ->result();

                if ($images) {
                    foreach ($images as &$image) {
                        $image = $image->id;
                    }

                    $this->imageDelete($images);
                }
            }


            $success = $this->db
                ->where_in('id', $data)
                ->delete($this->table);

            if ($success) {
                foreach ($records as $record) {
                    @unlink("../public/upload/estate/{$record->image}");
                }
            }

            return $success;
        }


        $images = $this->db
            ->from('estate_images')
            ->where('estateId', $data->id)
            ->get()
            ->result();

        if ($images) {
            foreach ($images as &$image) {
                $image = $image->id;
            }

            $this->imageDelete($images);
        }



        $success = $this->db
            ->where('id', $data->id)
            ->delete($this->table);

        @unlink("../public/upload/estate/{$data->image}");

        return $success;
    }


    public function image($id)
    {
        return $this->db
            ->from('estate_images')
            ->where('id', $id)
            ->get()
            ->row();
    }


    public function imageAll($parent, $limit = null, $offset = null)
    {
        $this->utils->filter();


        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->from('estate_images')
            ->where('estateId', $parent->id)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function imageCount($parent)
    {
        $this->utils->filter();

        return $this->db
            ->from('estate_images')
            ->where('estateId', $parent->id)
            ->count_all_results();
    }


    public function imageInsert($parent, $data = array())
    {
        $order = 1;
        $lastOrderRecord = $this->db
            ->from('estate_images')
            ->where('estateId', $parent->id)
            ->order_by('order', 'desc')
            ->limit(1)
            ->get()
            ->row();


        if ($lastOrderRecord) {
            $order = $lastOrderRecord->order + 1;
        }


        $this->db->insert('estate_images', array(
            'estateId' => $parent->id,
            'image' => $data['image']['name'],
            'order' => $order,
        ));

        return $this->db->insert_id();
    }



    public function imageUpdate($record, $data = array())
    {
        $this->db
            ->where('id', $record->id)
            ->update('estate_images', array(
                'image' => $data['image']['name'],
            ));

        return $this->db->affected_rows();
    }



    public function imageDelete($data)
    {
        if (is_array($data)) {
            $records = $this->db
                ->from('estate_images')
                ->where_in('id', $data)
                ->get()
                ->result();

            $success = $this->db
                ->where_in('id', $data)
                ->delete('estate_images');

            if ($success) {
                foreach ($records as $record) {
                    @unlink("../public/upload/estate/thumb/{$record->image}");
                    @unlink("../public/upload/estate/normal/{$record->image}");
                    @unlink("../public/upload/estate/large/{$record->image}");
                }
            }

            return $success;
        }

        $success = $this->db
            ->where('id', $data->id)
            ->delete('estate_images');

        @unlink("../public/upload/estate/thumb/{$data->image}");
        @unlink("../public/upload/estate/normal/{$data->image}");
        @unlink("../public/upload/estate/large/{$data->image}");

        return $success;
    }


    public function imageOrder($ids = null)
    {
        if (is_array($ids)) {
            $records = $this->db
                ->from('estate_images')
                ->where_in('id', $ids)
                ->order_by('order', 'asc')
                ->order_by('id', 'desc')
                ->get()
                ->result();

            $firstOrder = 0;
            $affected = 0;

            foreach ($records as $record) {
                if ($firstOrder === 0) {
                    $firstOrder = $record->order;
                }

                $order = array_search($record->id, $ids) + $firstOrder;

                if ($record->order != $order) {
                    $this->db
                        ->where('id', $record->id)
                        ->update('estate_images', array('order' => $order));

                    if ($this->db->affected_rows() > 0) {
                        $affected++;
                    }
                }

            }

            return $affected;
        }

    }




    public function content($id)
    {
        return $this->db
            ->from('product_contents')
            ->where('id', $id)
            ->where('language', $this->language)
            ->get()
            ->row();
    }


    public function contentAll($parent, $limit = null, $offset = null)
    {
        $this->utils->filter();


        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->from('product_contents')
            ->where('productId', $parent->id)
            ->where('language', $this->language)
            ->order_by('order', 'asc')
            ->order_by('id', 'asc')
            ->get()
            ->result();
    }


    public function contentCount($parent)
    {
        $this->utils->filter();

        return $this->db
            ->from('product_contents')
            ->where('productId', $parent->id)
            ->where('language', $this->language)
            ->count_all_results();
    }


    public function contentInsert($parent, $data = array())
    {
        $order = 1;
        $lastOrderRecord = $this->db
            ->from('product_contents')
            ->where('productId', $parent->id)
            ->where('language', $this->language)
            ->order_by('order', 'desc')
            ->limit(1)
            ->get()
            ->row();


        if ($lastOrderRecord) {
            $order = $lastOrderRecord->order + 1;
        }


        $this->db->insert('product_contents', array(
            'productId' => $parent->id,
            'title' => $this->input->post('title'),
            'detail' => $this->input->post('detail'),
            'image' => $data['image']['name'],
            'order' => $order,
            'language' => $this->language,
        ));

        return $this->db->insert_id();
    }



    public function contentUpdate($record, $data = array())
    {
        $this->db
            ->where('id', $record->id)
            ->update('product_contents', array(
                'title' => $this->input->post('title'),
                'detail' => $this->input->post('detail'),
                'image' => $data['image']['name'],
            ));

        return $this->db->affected_rows();
    }



    public function contentDelete($data)
    {
        if (is_array($data)) {
            $records = $this->db
                ->from('product_contents')
                ->where_in('id', $data)
                ->get()
                ->result();

            $success = $this->db
                ->where_in('id', $data)
                ->delete('product_contents');

            if ($success) {
                foreach ($records as $record) {
                    @unlink("../public/upload/product/content/{$record->image}");
                    @unlink("../public/upload/product/content/{$record->image}");
                }
            }

            return $success;
        }

        $success = $this->db
            ->where('id', $data->id)
            ->delete('product_contents');

        @unlink("../public/upload/product/content/{$data->image}");
        @unlink("../public/upload/product/content/{$data->image}");


        return $success;
    }


    public function contentOrder($ids = null)
    {
        if (is_array($ids)) {
            $records = $this->db
                ->from('product_contents')
                ->where_in('id', $ids)
                ->where('language', $this->language)
                ->order_by('order', 'asc')
                ->order_by('id', 'desc')
                ->get()
                ->result();

            $firstOrder = 0;
            $affected = 0;

            foreach ($records as $record) {
                if ($firstOrder === 0) {
                    $firstOrder = $record->order;
                }

                $order = array_search($record->id, $ids) + $firstOrder;

                if ($record->order != $order) {
                    $this->db
                        ->where('id', $record->id)
                        ->update('gallery_contents', array('order' => $order));

                    if ($this->db->affected_rows() > 0) {
                        $affected++;
                    }
                }

            }

            return $affected;
        }

    }

} 