<?php

class Estatecontact extends CI_Model
{

    public function id($id)
    {
        return $this->db
            ->select("{$this->table}.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, ' / ', districts.title, ', ', towns.title, ' - ', cities.title) estateTitle", false)
            ->from($this->table)
            ->join('estates', "estates.id = {$this->table}.estateId")
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->where("{$this->table}.id", $id)
            ->get()
            ->row();
    }


    public function all($limit = null, $offset = null)
    {
        $this->utils->filter();


        if ($limit != null) {
            $this->db->limit($limit, $offset);
        }

        return $this->db
            ->select("{$this->table}.*, CONCAT('#',estates.no, ' - ', estates.estateStatus, ' ', types.title, ' / ', districts.title, ', ', towns.title, ' - ', cities.title) estateTitle", false)
            ->from($this->table)
            ->join('estates', "estates.id = {$this->table}.estateId")
            ->join('cities', 'cities.id = estates.cityId')
            ->join('towns', 'towns.id = estates.townId')
            ->join('districts', 'districts.id = estates.districtId')
            ->join('types', 'types.id = estates.typeId')
            ->order_by("{$this->table}.id", 'desc')
            ->get()
            ->result();
    }


    public function count()
    {
        $this->utils->filter();

        return $this->db
            ->from($this->table)
            ->count_all_results();
    }




    public function viewed($record, $data = array())
    {
        $this->db
            ->where('id', $record->id)
            ->update($this->table, array(
                'viewed' => 1
            ));

        return $this->db->affected_rows();
    }




    public function delete($data)
    {
        if (is_array($data)) {
            $success = $this->db
                ->where_in('id', $data)
                ->delete($this->table);

            return $success;
        }

        $success = $this->db
            ->where('id', $data->id)
            ->delete($this->table);


        return $success;
    }


} 