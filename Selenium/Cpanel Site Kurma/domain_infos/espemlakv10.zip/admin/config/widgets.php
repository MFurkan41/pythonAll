<?php

$config['widgets'] = array(

    array(
        'type' => 'app-full',
        'class' => 'app-success',
        'module' => 'estate',
        'icon'	=> 'fa-building-o',
        'label'	=> 'Kiralık Emlaklar',
        'where' => array('estateStatus' => 'Kiralık'),
        'link' => 'estate/records/?estateStatus=Kiralık'
    ),
    array(
        'type' => 'app-full',
        'class' => 'app-success',
        'module' => 'estate',
        'icon'	=> 'fa-building-o',
        'label'	=> 'Satılık Emlaklar',
        'where' => array('estateStatus' => 'Satılık'),
        'link' => 'estate/records/?estateStatus=Satılık'
    ),

	array(
		'module' => 'contact',
		'icon'	=> 'fa-envelope',
		'info'	=> 'Yeni',
		'where' => array('viewed' => 0)
	),
    array(
        'module' => 'estatecontact',
        'icon'	=> 'fa-envelope',
        'info'	=> 'Yeni',
        'where' => array('viewed' => 0)
    ),
    array(
        'module' => 'estateinsert',
        'icon'	=> 'fa-building-o',
        'info'	=> 'Aktarılmayan',
        'where' => array('moved' => 0)
    ),
    array(
        'module' => 'callyou',
        'icon'	=> 'fa-phone',
    ),

);
