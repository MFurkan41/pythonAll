<?php

$config['analytics'] = array(

);
