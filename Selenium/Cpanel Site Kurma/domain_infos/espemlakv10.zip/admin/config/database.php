<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require '../application/config/database.php';
