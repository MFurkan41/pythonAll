<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>404 Sayfa bulunamadı.</title>

    <style type="text/css">
        body {margin: 0; font: 13px/20px normal Helvetica, Arial, sans-serif; color: #333;}
        a {color: #296c6c; text-decoration: none;}
        h1 {font-size: 24px; margin-top: 20px;}
        p {margin: 12px 15px 12px 15px;}
        #container {width: 427px; margin: 5% auto 0 auto;}

    </style>
</head>
<body>
<div id="container">
    <h1>Sayfa bulunamadı!</h1>
    Erişmek istediğiniz sayfa bulunamadı. <br />Kayıt silinmiş yada aktif dil değiştirilmiş olabilir.<br /><br />
    <a href="javascript:history.back();"><strong>Geri dön</strong></a>
</div>
</body>
</html>