<?php
$config['languages'] = array(
    'tr' => 'Türkçe',
    'en' => 'İngilizce'
);
