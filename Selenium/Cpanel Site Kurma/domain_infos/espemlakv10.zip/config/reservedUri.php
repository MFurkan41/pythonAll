<?php

$config['reservedUri']['tr']['@content'] = 'icerik';
$config['reservedUri']['tr']['@estateinsert'] = 'emlak-ekle';
$config['reservedUri']['tr']['@estate'] = 'emlak';
$config['reservedUri']['tr']['@rent'] = 'kiralik';
$config['reservedUri']['tr']['@sale'] = 'satilik';
$config['reservedUri']['tr']['@search'] = 'ara';
$config['reservedUri']['tr']['@wecallyou'] = 'biz-sizi-arayalim';
$config['reservedUri']['tr']['@gallery'] = 'galeri';
$config['reservedUri']['tr']['@blogpost'] = 'blog/yazi';
$config['reservedUri']['tr']['@blogcategory'] = 'blog/kategori';
$config['reservedUri']['tr']['@blog'] = 'blog';
$config['reservedUri']['tr']['@contact'] = 'iletisim';
$config['reservedUri']['tr']['@video'] = 'video';
